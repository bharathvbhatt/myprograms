#!/bin/wsapi.cgi

-- Set this manually so we can override it while unit testing
package.path = package.path .. ";./backend/?.lua"

local orbit = require "orbit"
local R = require "orbit.routes"
local json = require "json"
local encode = json.encode
local decode = json.decode

local engine = orbit.new ()
local api_version = 1

-- Not currently used, but can be used for building up
-- custom API calls.
local fields = {
	Auth = {
	},
	Config = {
	},
	User = {
	},
	SerialPorts = {
	},
	SecureShell = {
	},
	NodeDescription = {},
  Script = {}
}

local methods = { 'post', 'get', 'put', 'delete', 'patch' }

-- These should maybe be loaded from their own files to prevent this getting too bloated
local commands = {
	-- Session management
	{route = "sessions", method = "post", object = "Auth", func = "session_create",
		fields = "Auth", min_version = 1, no_trans = true, no_auth = true},
	{route = "sessions/:sid", method = "get", object = "Auth", func = "session_get",
		fields = "Auth", min_version = 1, no_trans = true, no_auth = true},
	{route = "sessions/:sid", method = "put", object = "Auth", func = "session_apply_response",
		fields = "Auth", min_version = 1, no_trans = true, no_auth = true},
	{route = "sessions/:sid", method = "delete", object = "Auth", func = "session_delete",
		fields = "Auth", min_version = 1, no_trans = true, no_auth = true},

	-- LH Enrollment
	{route = "registration", method = "post", object = "Enrollment",
		func = "create_registration", fields = "Config", min_version = 1},
	{route = "registration", method = "delete", object = "Enrollment",
	 func = "delete_registration", fields = "Config", min_version = 1},
	{route = "registration/:id/server_address", method = "put", object = "Enrollment",
	 func = "update_server_address", fields = "Config", min_version = 1},

	-- Serial Ports
	{route = "serialPorts", method = "get", object = "SerialPorts",
	 func = "get_port_list", fields = "SerialPorts", min_version = 1},
	{route = "serialPorts/:id", method = "get", object = "SerialPorts",
	 func = "get_port", fields = "SerialPorts", min_version = 1},

	-- Groups
	{route = "groups", method = "get", object = "Groups",
	 func = "get_group_list", fields = "Groups", min_version = 1},
	{route = "groups", method = "delete", object = "Groups",
	 func = "delete_group_list", fields = "Groups", min_version = 1},
	{route = "groups", method = "put", object = "Groups",
	 func = "put_group_list", fields = "Groups", min_version = 1},
	{route = "groups/:id", method = "get", object = "Groups",
	 func = "get_group", fields = "Groups", min_version = 1},

	-- Auth
	{route = "auth", method = "get", object = "AuthConfig",
	 func = "get_auth", fields = "AuthConfig", min_version = 1},
	{route = "auth", method = "put", object = "AuthConfig",
	 func = "put_auth", fields = "AuthConfig", min_version = 1},

	-- Secure Shell
	{route = "secureShell", method = "get", object = "SecureShell",
	 func = "get_ssh", fields = "SecureShell", min_version = 1},
	{route = "secureShell/keys/host", method = "get", object = "SecureShell",
	 func = "get_host_keys", fields = "SecureShell", min_version = 1},
	-- FIXME: insertion of authorized keys should be secured!
	-- FIXME: ye olde cherokee on console server does not support patch
	{route = "secureShell/keys/user/:username/authorized", method = "put", object = "SecureShell",
	 func = "patch_user_authorized_keys", fields = "SecureShell", min_version = 1},

	-- NodeDescription
	-- FIXME?: method = "post"?
	{route = "nodeDescription", method = "get", object = "NodeDescription",
	 func = "get_node_description", fields = "NodeDescription", min_version = 1},

	-- Script
	{route = "scripts", method = "post", object = "Scripts",
	 func = "post_script", fields = "Scripts", min_version = 1},
	{route = "scripts", method = "get", object = "Scripts",
	 func = "get_script_status", fields = "Scripts", min_version = 1},
}

local objects = {}
objects["Auth"] = require "commands/Auth"
objects["Enrollment"] = require "commands/Enrollment"
objects["SerialPorts"] = require "commands/SerialPorts"
objects["Groups"] = require "commands/Groups"
objects["SecureShell"] = require "commands/SecureShell"
objects["NodeDescription"] = require "commands/NodeDescription"
objects["AuthConfig"] = require "commands/AuthConfig"
objects["Scripts"] = require "commands/Scripts"

engine.not_found = function (web)
	web.status = "404 Not Found"
	return [[<html><head><title>Not Found</title></head>
				 <body><p>404 - not found.</p><p>
				 URI:]] .. web.path_info .. [[</p></body></html>]]
end

function not_supported (web)
	web.status = "405 Method Not Allowed"
	return [[<html><head><title>Method Not Allowed</title></head>
				 <body><p>405 - method not allowed.</p><p>
				 URI:]] .. web.path_info .. [[</p></body</html>]]
end

function exec_command (obj, auth_required, func, fieldset, version, in_transaction)
	return function (web, params)

		-- Check authorization if this command is not exempt. Auth methods will
		-- build response on failure.
		if auth_required then
			--os.execute("logger \"auth required for " .. web.path_info .. "\"");
			is_authed, web_resp = objects["Auth"].is_authenticated(web)
			if not is_authed then return web_resp end
		end
		--os.execute("logger \"authentication successfull\"");

		path = web.path_info
		qmark = string.find (path, "?")
		if qmark ~= nil then
			before = string.sub (path, string.len (web.prefix) + 1, qmark - 1)
		else
			before = string.sub (path, string.len (web.prefix) + 1)
		end
		-- Strip trailing slashes in the path
		before = before:gsub ("\/+$", "")
		--cherokee doesn't pass in the /api to our path_info (which is probably correct)
		web.path = "/api/" .. before
		local handle = nil
		local output = objects[obj][func] (web, params, fields[fieldset], handle)
		-- FIXME: JSONP callback content_type should be "application/javascript"
		if web.GET.jsonpCallback then
			output = web.GET.jsonpCallback .. "(" .. output .. ");"
		end

		return output
	end
end


available_methods = {}

-- Setup the callbacks for valid url/method combinations
for index, command in pairs(commands) do
	min = 1
	if command.min_version then
		min = command.min_version
	end
	max = api_version
	if command.max_version then
		max = command.max_version
	end

	for version = min, max do
		if not available_methods[command.route] then available_methods[command.route] = {} end
		available_methods[command.route][command.method] = true
		engine['dispatch_' .. command.method] (
			engine,
			exec_command (command.object, not command.no_auth, command.func, command.fields, version, false),
			R("/v" .. version .. "/" .. command.route))
		if command.no_trans ~= true then
			engine['dispatch_' .. command.method] (
				engine,
				exec_command (command.object, not command.no_auth, command.func, command.fields, version, true),
				R("/v" .. version .. "/transactions/:tid/" .. command.route))
		else
			engine['dispatch_' .. command.method] (
				engine,
				not_supported,
				R("/api/v" .. version .. "/transactions/:tid/" .. command.route))
		end
	end
end

-- Return forbidden for non-supported methods for valid urls
for i,method in pairs(methods) do
	for url, url_list in pairs(available_methods) do
		if not url_list[method] then
			engine['dispatch_' .. method] (engine, not_supported, R(url))
		end
	end
end

return engine

-- vim: set tabstop=4 softtabstop=4 shiftwidth=4 noexpandtab : --
