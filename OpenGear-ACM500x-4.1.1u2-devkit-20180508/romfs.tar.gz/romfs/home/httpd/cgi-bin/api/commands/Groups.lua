local Groups = {}

--- Includes
local json = require "json"
local common = require "commands/common"
local bit = require "bit"
local md5 = require "md5"

require "luaconfig"

function Groups.delete_group_list(web, params, fields, handle)
	web:content_type ("application/json")

	-- Open and read the config
	local mgr = luaconfig.ConfigManager()
	if (mgr == nil) or (not mgr:read()) then
		web.status = 500
		return json.encode({['error'] = 'Failed to open configuration handle'})
	end

		-- Delete old groups
	local clm = luaconfig.ConfigListManager (mgr, "config.groups", "group")
	local i = 1
	while i <= clm:size() do
		local groupname = clm:getItem (i).second:get("name").value
		if luaconfig.group_is_system (groupname) == false then
			clm:deleteItem (i)
		else
			i = i + 1
		end
	end

	-- Save changes and return
	clm:saveList ()
	if not mgr:write () then
		web.status = 500
		return json.encode { message = "Failed to reload server configuration." }
	end

	mgr:schedule ("users")
	if not mgr:run () then
		web.status = 500
		return json.encode { message = "Failed to reload server configuration." }
	end

	web.status = 200
	return json.encode { message = "OK" }
end

function Groups.put_group_list(web, params, fields, handle)
	web:content_type ("application/json")

	-- Open and read the config
	local mgr = luaconfig.ConfigManager()
	if (mgr == nil) or (not mgr:read()) then
		web.status = 500
		return json.encode({['error'] = 'Failed to open configuration handle'})
	end

	-- Validate input looks sane
	local post_data = web.vars.input:read ()
	local success, body = common.safeDecode (post_data)
	if success == false then
		web.status = 400
		return json.encode ({['error'] = "Failed to parse request data"})

	end

	if common.jsonNullOrNil (body.groups) then
		web.status = 500
		return json.encode({['error'] = 'No group list provided'})
	end

	-- validate that it won't overwrite any system groups and that there are
	-- no duplicate groups.
	local replace_netgrp = false
	local groups = body.groups
	local group_dup_chk = {}
	for _, group in pairs (body.groups) do
		if luaconfig.group_is_system (group.name) then
			if group.name ~= "netgrp" then
				web.status = 409
				return json.encode({['error'] = 'Cannot overwrite system group ' .. group.name})
			else
				replace_netgrp = true
			end
		end
		if group_dup_chk[group] ~= nil then
			web.status = 400
			return json.encode({['error'] = 'Duplicate group in request ' .. group.name})
		else
			group_dup_chk[group] = true
		end
	end

	-- Delete old groups
	local clm = luaconfig.ConfigListManager (mgr, "config.groups", "group")
	local i = 1
	while i <= clm:size() do
		local groupname = clm:getItem (i).second:get("name").value
		if luaconfig.group_is_system (groupname) == false or (groupname == 'netgrp' and replace_netgrp == true) then
			clm:deleteItem (i)
		else
			i = i + 1
		end
	end

	-- Populate new groups
	for _, group in pairs (body.groups) do
		local grouptree = luaconfig.ConfigSubtree ()
		grouptree:get ("name").value = group.name
		grouptree:get ("description").value = group.description

		-- Populate roles
		if not common.jsonNullOrNil (group.roles) then
			for j = 1, #group.roles do
				grouptree:get ("roles"):get ("role" .. j).value = group.roles[j]
			end
			grouptree:get("roles"):get("total").value = #group.roles
		end

		-- And ports
		if not common.jsonNullOrNil (group.ports) then
			for j = 1, #group.ports do
				if group.ports[j] then
					grouptree:get ("port" .. j).value = "on"
				end
			end
		end
		clm:addItem (grouptree)
	end

	-- Save changes and return
	clm:saveList ()
	if not mgr:write () then
		web.status = 500
		return json.encode { message = "Failed to reload server configuration." }
	end

	mgr:schedule ("users")
	if not mgr:run () then
		web.status = 500
		return json.encode { message = "Failed to reload server configuration." }
	end

	web.status = 201
	return Groups.get_group_list (web, params, fields, handle)
end

local function get_group_table(mgr, group_num)
	assert(type(group_num) == 'number')

	-- Build group prefix
	local pref = 'config.groups.group' .. group_num .. '.'

	-- Populate basic data
	local g = {id = string.format('group%d', group_num)}
	g.description = common.get_config_elem (mgr, pref .. "description", '', true)
	g.name = common.get_config_elem (mgr, pref .. "name", nil, false)
	if g.name == nil then
		return nil, "Invalid group ID"
	end
	
	-- Populate roles
	g.roles = {}
	local clm = luaconfig.ConfigListManager (mgr, pref .. "roles", "role")
	for i = 1,clm:size() do
	   local pair = clm:getItem (i)
	   g.roles[i] = pair.second.value
	end

	-- Populate group permissions
	local port_count = mgr:getNumSerialPorts() + mgr:getNumSlavePorts()
	g.ports = {}
	for i = 1, port_count do
	   g.ports[i] = mgr:getBoolean (pref .. "port" .. i)
	end

	g.system = luaconfig.group_is_system (g.name)

	return g, nil
end

function Groups.get_group(web, params, fields, handle)
	web:content_type ("application/json")

	-- Open and read the config
	local mgr = luaconfig.ConfigManager()
	if (mgr == nil) or (not mgr:read()) then
		web.status = 500
		return json.encode({['error'] = 'Failed to open configuration handle'})
	end

	-- Check group id is a string 'groupN' and retrieve the group number
	local group_id = (type(params.id) == 'string') and params.id or ''
	local group_number = tonumber(string.match(group_id, 'group([0-9]+)'))
	if (group_number == nil) or (group_number <= 0)  then
		web.status = 404
		return json.encode({['error'] = 'Invalid Group ID:' .. group_id })
	end

	-- Get group information
	local group_data, err = get_group_table(mgr, group_number)
	if group_data == nil then
		web.status = 404
		return json.encode({['error'] = err})
	end

	local strdata = json.encode({group = group_data})
	web.headers["ETag"] = md5.sumhexa (strdata)
	if web.headers["ETag"] == web.vars["HTTP_IF_NONE_MATCH"] then
		web.status = 304
		return json.encode ({})
	else
		web.status = 200
		return strdata
	end
end

function Groups.get_group_list(web, params, fields, handle)
	web:content_type ("application/json")

	-- Pagination is optional so start with an improbable page size
	local page_size = 100000
	local page_num = 1

	-- Callers must specify both pagination variables or neither
	local paginated = false
	if (web.GET.per_page ~= nil) and (web.GET.page ~= nil) then
		page_size = tonumber(web.GET.per_page)
		page_num = tonumber(web.GET.page)

		if page_size == nil or page_num == nil or page_size <= 0 or page_num <= 0 then
			web.status = 400
			return json.encode({['error'] = 'Invalid pagination values'})
		end
		paginated = true

	elseif (web.GET.per_page ~= nil) or (web.GET.page ~= nil) then
		web.status = 400
		return json.encode({['error'] = 'Invalid partial pagination request'})
	end

	-- Open and read the config
	local mgr = luaconfig.ConfigManager()
	if (mgr == nil) or (not mgr:read()) then
		web.status = 500
		return json.encode({['error'] = 'Failed to open configuration handle'})
	end

	-- Groups are 'numbered' from 1. The paginated list of groups have
	-- string 'id' fields so strictly this isn't an 'indexed' array.
	local start = 1 + ((page_num - 1) * page_size)
	local finish = page_num * page_size

	local clm = luaconfig.ConfigListManager (mgr, "config.groups", "group")

	local group_count = clm:size()
	if start > group_count then start = 0 end
	if finish > group_count then finish = group_count end

	local groups = {}
	if start <= finish and start > 0 then
		for group_num = start, finish, 1 do
			local p, err = get_group_table(mgr, group_num)

			-- Groups within this range must be retrievable as range was checked
			if p == nil then
				web.status = 500
				return json.encode({
					['error'] = 'Failed to retrieve group details: ' .. err})
			end

			groups[#groups + 1] = p
		end
	end

	-- Determine total number of pages at this page size. If there are no groups
	-- then there's still 1 page with 0 entries.
	local total_pages = math.max(1, math.ceil(group_count / page_size))

	-- Encode 'meta' with total_pages field for ember-cli-pagination supgroup
	local ret_body = {groups = groups, meta = {total_pages = total_pages}}

	-- Force json encoder to treat groups as an array even when empty
	json.util.InitArray(ret_body.groups)

	local strdata = json.encode(ret_body)
	web.headers["ETag"] = md5.sumhexa (strdata)
	if web.headers["ETag"] == web.vars["HTTP_IF_NONE_MATCH"] then
		web.status = 304
		return json.encode ({})
	else
		web.status = 200
		return strdata
	end
end


return Groups
