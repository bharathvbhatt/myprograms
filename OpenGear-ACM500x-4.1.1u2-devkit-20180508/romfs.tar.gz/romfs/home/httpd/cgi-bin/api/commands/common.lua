local decode = json.decode

local Common = {}

function Common.safeDecode(data)
	local body = nil
	local success, value = pcall(decode, data)
	if success then
		body = value
	end
	return success, body
end

--
-- check if an object is 'non existent' include a check for the
-- json null 'object'.
--
function Common.jsonNullOrNil(value)
	return (value == nil or value == json.util.null)
end
--
-- check if an object is 'non existent or empty' include a check for the 
-- json null 'object'.
--
function Common.jsonNullNilOrEmpty(value) 
	return (value == nil or value == '' or value == json.util.null)
end

--- Tokenize a string based on the provided separator character.
-- @param inputstr A string to tokenize
-- @param sep A separator character (1 length string) or nil to use spaces.
-- @param mutator A mutator to apply to each token (for convenience)
-- @returns A contiguous table with integer keys (array) of tokenized values.
function Common.tokenizeString(inputstr, sep, mutator)
	-- Separate on whitespace if no separator provided
	if sep == nil then sep = "%s" end
	local t={}
	for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
		if mutator ~= nil then str = mutator(str) end
		t[#t+1]=str
	end
	return t
end

--- Return a copy of 's' with leading and trailing whitespace removed.
function Common.trimString(s)
	return (s:gsub("^%s*(.-)%s*$", "%1"))
end


--- Retrieve the value for config element.
-- ConfigManager conflates missing fields and default values so retrieving a
-- string which is missing will return '' and so will an empty string.
function Common.get_config_elem(mgr, key, default, empty_is_valid)

	local v = mgr:getElement(key)

	if (v == nil) or (type(v) ~= 'string') then
		return default
	end

	if (not empty_is_valid) and (string.len(v) <= 0) then
		return default
	end
	return v
end



return Common

-- vim: set tabstop=4 softtabstop=4 shiftwidth=4 noexpandtab : --
