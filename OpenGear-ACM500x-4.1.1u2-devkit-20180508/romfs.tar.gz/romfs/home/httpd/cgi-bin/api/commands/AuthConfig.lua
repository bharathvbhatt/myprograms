local AuthConfig = {}

--- Includes
local json = require "json"
local common = require "commands/common"
local bit = require "bit"
local md5 = require "md5"

require "luaconfig"

function AuthConfig.put_auth (web, params, fields, handle)
	web:content_type ("application/json")

	-- Open and read the config
	local mgr = luaconfig.ConfigManager()
	if (mgr == nil) or (not mgr:read()) then
		web.status = 500
		return json.encode({['error'] = 'Failed to open configuration handle'})
	end

	-- Validate input looks sane
	local post_data = web.vars.input:read ()
	local success, body = common.safeDecode (post_data)
	if success == false then
		web.status = 400
		return json.encode ({['error'] = "Failed to parse request data"})

	end

	if common.jsonNullOrNil (body.auth) then
		web.status = 400
		return json.encode({['error'] = 'No auth object provided'})
	end

	if common.jsonNullOrNil (body.auth.auth_type) then
		web.status = 400
		return json.encode({['error'] = 'No auth type provided'})
	end

	local auth = body.auth

	-- Delete existing auth subtree
	luaconfig.deleteTree (mgr, "config.auth")

	-- Populate new auth config
	local auth_cfg = luaconfig.ConfigSubtree ()
	auth_cfg:get ("type").value = auth.auth_type

	if not common.jsonNullOrNil (auth.use_remote_groups) then
		if auth.use_remote_groups == true then
			auth_cfg:get ("useremotegroups").value = "on"
		end
	end

	if auth.auth_type == "RADIUS" or auth.auth_type == "RADIUSLocal" or auth.auth_type == "RADIUSDownLocal" then
		if common.jsonNullOrNil (auth.radius) then
			web.status = 400
			return json.encode({['error'] = 'Invalid request body'})
		end

		local radius_cfg = luaconfig.ConfigSubtree (mgr, "config.auth.radius")

		if not common.jsonNullOrNil (auth.radius.auth_server) then
			radius_cfg:get ("auth_server").value = auth.radius.auth_server
		end

		if not common.jsonNullOrNil (auth.radius.acct_server) then
			radius_cfg:get ("acct_server").value = auth.radius.acct_server
		end

		if not common.jsonNullOrNil (auth.radius.password) then
			radius_cfg:get ("password").value = auth.radius.password
		end

		radius_cfg:save (mgr, "config.auth.radius")

	elseif auth.auth_type == "TACACS" or auth.auth_type == "TACACSLocal" or auth.auth_type == "TACACSDownLocal" then
		if common.jsonNullOrNil (auth.tacacs) then
			web.status = 400
			return json.encode({['error'] = 'Invalid request body'})
		end

		local tacacs_cfg = luaconfig.ConfigSubtree (mgr, "config.auth.tacacs")

		if not common.jsonNullOrNil (auth.tacacs.auth_server) then
			tacacs_cfg:get ("auth_server").value = auth.tacacs.auth_server
		end

		if not common.jsonNullOrNil (auth.tacacs.password) then
			tacacs_cfg:get ("password").value = auth.tacacs.password
		end

		if not common.jsonNullOrNil (auth.tacacs.auth_method) then
			tacacs_cfg:get ("auth_method").value = auth.tacacs.auth_method
		end

		if not common.jsonNullOrNil (auth.tacacs.service) then
			tacacs_cfg:get ("service").value = auth.tacacs.service
		end

		tacacs_cfg:save (mgr, "config.auth.tacacs")

	elseif auth.auth_type == "LDAP" or auth.auth_type == "LDAPLocal" or auth.auth_type == "LDAPDownLocal" then
		if common.jsonNullOrNil (auth.ldap) then
			web.status = 400
			return json.encode({['error'] = 'Invalid request body'})
		end

		local ldap_cfg = luaconfig.ConfigSubtree (mgr, "config.auth.ldap")

		if not common.jsonNullOrNil (auth.ldap.auth_server) then
			ldap_cfg:get ("server").value = auth.ldap.auth_server
		end

		if not common.jsonNullOrNil (auth.ldap.base_dn) then
			ldap_cfg:get ("basedn").value = auth.ldap.base_dn
		end

		if not common.jsonNullOrNil (auth.ldap.bind_dn) then
			ldap_cfg:get ("binddn").value = auth.ldap.bind_dn
		end

		if not common.jsonNullOrNil (auth.ldap.username_attr) then
			ldap_cfg:get ("loginattr").value = auth.ldap.username_attr
		end

		if not common.jsonNullOrNil (auth.ldap.group_attr) then
			ldap_cfg:get ("memberattr").value = auth.ldap.group_attr
		end

		if not common.jsonNullOrNil (auth.ldap.password) then
			ldap_cfg:get ("password").value = auth.ldap.password
		end

		ldap_cfg:save (mgr, "config.auth.ldap")
	end

	-- Save changes and return
	auth_cfg:save (mgr, "config.auth")
	if not mgr:write () then
		web.status = 500
		return json.encode { ['error'] = "Failed to write changes to server configuration." }
	end

	-- Regenerate the auth config
	mgr:schedule ("auth")
	if not mgr:run () then
		web.status = 500
		return encode { ['error'] = "Failed to reload server configuration." }
	end

	web.status = 201
	return AuthConfig.get_auth (web, params, fields, handle)
end

function AuthConfig.get_auth(web, params, fields, handle)
	web:content_type ("application/json")

	-- Open and read the config
	local mgr = luaconfig.ConfigManager()
	if (mgr == nil) or (not mgr:read()) then
		web.status = 500
		return json.encode({['error'] = 'Failed to open configuration handle'})
	end

	-- Build auth prefix
	local pref = "config.auth."

	-- Get auth information
	local a = {}
	a.auth_type = common.get_config_elem (mgr, pref .. "type")

	a.use_remote_groups = (common.get_config_elem (mgr, pref .. "useremotegroups") == "on")

	-- RADIUS
	a.radius = {}
	a.radius.auth_server = common.get_config_elem (mgr, pref .. "radius.auth_server")
	a.radius.acct_server = common.get_config_elem (mgr, pref .. "radius.acct_server")
	a.radius.password = common.get_config_elem (mgr, pref .. "radius.password")

	-- TACACS
	a.tacacs = {}
	a.tacacs.auth_server = common.get_config_elem (mgr, pref .. "tacacs.auth_server")
	a.tacacs.password = common.get_config_elem (mgr, pref .. "tacacs.password")
	a.tacacs.auth_method = common.get_config_elem (mgr, pref .. "tacacs.auth_method")
	a.tacacs.service = common.get_config_elem (mgr, pref .. "tacacs.service")

	-- LDAP
	a.ldap = {}
	a.ldap.server = common.get_config_elem (mgr, pref .. "ldap.server")
	a.ldap.base_dn = common.get_config_elem (mgr, pref .. "ldap.basedn")
	a.ldap.bind_dn = common.get_config_elem (mgr, pref .. "ldap.binddn")
	a.ldap.username_attr = common.get_config_elem (mgr, pref .. "ldap.loginattr")
	a.ldap.group_membership_attr = common.get_config_elem (mgr, pref .. "ldap.memberattr")
	a.ldap.bind_password = common.get_config_elem (mgr, pref .. "ldap.password")

	local strdata = json.encode({auth = a})
	web.headers["ETag"] = md5.sumhexa (strdata)
	if web.headers["ETag"] == web.vars["HTTP_IF_NONE_MATCH"] then
		web.status = 304
		return json.encode ({})
	else
		web.status = 200
		return strdata
	end
end

return AuthConfig
