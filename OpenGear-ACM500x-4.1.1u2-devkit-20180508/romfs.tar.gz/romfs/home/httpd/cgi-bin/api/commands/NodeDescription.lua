-------------------------------------------------------------------------------
-- Node Description configuration for Opengear devices.
-- @module NodeDescription
-- @author Don Coolidge<don.coolidge@opengear.com>
-- @copyright 2017 Opengear
--
-- Design / documentation for this API is available at:
-- https://cvs.opengear.com:8443/Product_Development/New_Architecture/Node_Description_REST_API
--
-- Ideally the data reported here should match what the console server CGI shows
-- at all times. This includes special logic for missing or empty fields and
-- entire missing sub-trees.
-------------------------------------------------------------------------------
local NodeDescription = {}

--- Includes
local json = require "json"
local common = require "commands/common"
local bit = require "bit"
local md5 = require "md5"

require "luaconfig"


--- Retrieve the value for config element.
-- ConfigManager conflates missing fields and default values so retrieving a
-- string which is missing will return '' and so will an empty string.
local function get_config_elem(mgr, key, default, empty_is_valid)
	
	local v = mgr:getElement(key)

	if (v == nil) or (type(v) ~= 'string') then
		return default
	end

	if (not empty_is_valid) and (string.len(v) <= 0) then
		return default
	end
	return v
end

local function get_model(mgr)

	local model = mgr:getElement("config.system.model")
	if (model == nil) or (string.len(model) <= 0) then
		return ''
	end
	return model
end

local function get_hostname(mgr)
	local hostname = mgr:getElement("config.system.name")
	if hostname == nil or hostname == "" then
		local f = io.popen ("/bin/hostname")
		hostname = f:read("*a") or ""
		f:close()
		hostname =string.gsub(hostname, "\n$", "")
	end
	return hostname
end

local function get_firmware_version(mgr)
	local version_file = io.open ("/etc/version")
	local line = version_file:read()
	version_file:close()
	if string.len(line) == 0 then
		return 'Unknown'
	end
	tokens = common.tokenizeString(line, " ")
	local version = tokens[3]
	if (version == nil) or (string.len(version) <= 0) then
		return 'Unknown'
	end
	return version

end

local function get_serial_number(mgr)
	local serial_num = mgr:getFeatureSetValue('serial_no')
	if (serial_num == nil) or (string.len(serial_num) <= 0) then
		return 'N/A'
	end
	return serial_num
end

local function get_interfaces(mgr)
	local interfaces = {}
	local ifvector = mgr:getInterfaceAddresses()
	local size = ifvector:size()
	for i=0,(size-1) do
		local iface = ifvector[i].first
		local addresses = ifvector[i].second
		-- For now, just use the first address. TODO: figure out if we want more or not.
		local address = ""
		if (addresses:size() > 0) then
			local a = addresses[0]
			if (a == "") or (a == "0.0.0.0") then
				a = 'Unknown'
			end
			address = a
		end
		table.insert(interfaces, {['name'] = iface, ['ipv4_address'] = address})
	end
	return interfaces
end

local function get_macaddr(mgr)
	local mac_file = io.open ("/sys/class/net/eth0/address")
	local line = mac_file:read()
	return line
end

--- Retrieve the node configuration description
--- to be displayed in the Lighthouse UI Enrolled Nodes page
-- @param mgr A ConfigManager userdata value
-- @returns strdata The parameters describing node (enum value missing = false etc)

function NodeDescription.get_node_description(web, params, fields, handle)
	web:content_type ("application/json")

	local comprehensive = (web.GET ~= nil and web.GET.comprehensive) and true or false

	-- Open and read the config
	local mgr = luaconfig.ConfigManager()
	if (mgr == nil) or (not mgr:read()) then
		web.status = 500
		return json.encode({['error'] = 'Failed to open configuration handle'})
	end

	-- Get the items of interest
	local model, err = get_model(mgr)
	if model == nil then
		web.status = 404
		return json.encode({['error'] = err})
	end
	local fw, err = get_firmware_version(mgr)
	if fw == nil then
		web.status = 404
		return json.encode({['error'] = err})
	end
	local serial, err = get_serial_number(mgr)
	if serial == nil then
		web.status = 404
		return json.encode({['error'] = err})
	end
	local macaddr, err = get_macaddr(mgr)
	if macaddr == nil then
		web.status = 404
		return json.encode({['error'] = err})
	end
	local ifaces, err = get_interfaces(mgr)
	if ifaces == nil then
		web.status = 404
		return json.encode({['error'] = err})
	end
	local hostname, err = get_hostname(mgr)
	if hostname == nil then
		web.status = 404
		return json.encode ({['error'] = err})
	end
	local ret_body = {model_number = model, serial_number = serial, firmware_version = fw, mac_address = macaddr, interfaces = ifaces, hostname = hostname}

	-- Force json encoder to treat interfaces as an array even when empty
	json.util.InitArray(ret_body.interfaces)

	local strdata = json.encode(ret_body)
	web.headers["ETag"] = md5.sumhexa (strdata)
	if web.headers["ETag"] == web.vars["HTTP_IF_NONE_MATCH"] then
		web.status = 304
		return json.encode ({})
	else
		web.status = 200
		return strdata
	end

end

return NodeDescription -- return module

