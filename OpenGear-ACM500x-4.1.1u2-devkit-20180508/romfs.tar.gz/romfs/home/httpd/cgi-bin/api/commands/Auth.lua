-------------------------------------------------------------------------------
-- Authentication (and later Authorisation) commands for Lighthouse REST API.
-- @module Auth
-- @author Justin Akers <justin.akers@opengear.com>
-- @copyright 2015 Opengear
--
-- This module provides Auth(entication|orization) HTTP command handlers for
-- the lighthouse REST API.
--
-- This implements the Basic components of RFC 2617 "HTTP Authentication"
-- see: http://www.ietf.org/rfc/rfc2617.txt
--
-- TODO: Investigate whether we should be abusing the "Authorization" HTTP
-- header here. Perhaps we should have our own "x-og-auth" header.
--
-- TODO: Should sessions be hashed into HTTP ETags via HTTP_IF_MATCH header?
--		 See http://www.ietf.org/rfc/rfc2616.txt 14.19
-------------------------------------------------------------------------------
local Auth = {}

--- Includes
local orbit = require 'orbit'
local json = require "json"
local basexx = require "basexx"
local common = require "commands/common"
local ogsession = require "libogsession_lua"
local ogutils = require "ogutils"

--- The default HTTP Basic realm
local Realm = "REST API"

--- Parse 'Authorization' field from request.
-- http://tools.ietf.org/html/rfc1945#section-10.2
-- @param web The orbit web request object.
-- @return scheme The scheme the client has specified OR nil if invalid.
-- @return components The parsed components (varies by scheme) OR nil if invalid.
local function get_http_authorization(web)

	--os.execute("logger \"SSL_CLIENT_VERIFY = " .. web.vars.SSL_CLIENT_VERIFY .. "\"");
	if (web.vars.SSL_CLIENT_VERIFY == 'SUCCESS') then
		return "Cert", nil
	end

	-- Get client-passed 'Authorization' (HTTP_AUTHORIZATION) field
	-- http://tools.ietf.org/html/rfc1945#section-10.2
	local http_auth_raw = web.vars.HTTP_AUTHORIZATION
	if http_auth_raw == nil then return nil end

	-- Trim whole credentials field
	local http_auth_trimmed = ogutils.trim(http_auth_raw)
	if (http_auth_trimmed == nil) or (http_auth_trimmed:len() <= 0) then
		return nil
	end

	-- Parse scheme and credentials separated by whitespace
	local req_scheme, req_cred = http_auth_trimmed:match("(%S+)%s(%S+)")

	-- Handle scheme types
	if req_scheme == "Basic" then
		-- Regular "Basic" HTTP auth
		local unbase = basexx.from_base64(req_cred)
		if unbase == nil then return nil end
		local left, right = unbase:match("(.*):(.*)")
		return req_scheme, {['left'] = left, ['right'] = right}

	elseif req_scheme == "Token" then
		-- Custom token-based authentication
		return req_scheme, {['token'] = req_cred}
	end

	-- Unknown authentication scheme
	return nil
end


--- Check if an orbit web request contains valid authentication details.
-- This may take the form of a session ID or, in future, a certificate.
function Auth.is_authenticated(web)
	-- Only "Token" (custom) authentication is accepted here.
	local scheme, comp = get_http_authorization(web)

	-- Attempt to validate session ID
	-- FIXME: Should our response differentiate between an expired session
	-- and an invalid one?
	local valid = false
	if (scheme == "Token") and (comp ~= nil) and (comp.token ~= nil) then
		local session = ogsession.Session(comp.token)
		if session ~= nil then
			valid = session:authSuccess()
		end
		if valid then
			-- FIXME: do other authorization, likely at a per-request level
			-- inside each handler. This will have to build upon the 'acl'
			-- based approach that we designed in IM-126
			if (not (session:hasAdmin())) then
				valid = false
			end
		end

	end
	if (scheme == "Cert") then
		valid = true
	end

	-- Report 401 on failure as per ember auth expectations. Don't attempt to
	-- redirect.
	-- NOTE: This ignores HTTP 401 requirement for 'WWW-Authenticate' header.
	local resp = nil
	if not valid then
		web:content_type ("application/json")
		web.status = 401
		resp = json.encode({['error'] = "Invalid token"})
	end
	return valid, resp
end

--- Attempt to create an authentication session
function Auth.session_create(web, params, fields, handle)

	-- Response body will be JSON
	web:content_type ("application/json")

	-- Parse JSON request body
	local body_data = web.vars.input:read()
	local success, body = common.safeDecode(body_data)
	if (not success) or (body.username == nil) or (body.password == nil) or
		(body.username == json.util.null) or (body.password == json.util.null) then
		web.status = 400
		return json.encode({['error'] = "Invalid request body"})
	end

	-- Attempt to create new session. Do not allow retries for invalid passwords.
	-- FIXME: get real expiries, 20 is the same default as in CS land
	session = ogsession.Session(body.username, body.password, 20, true, false);
	if session:isValid() then
		if session:continueSession() then
			if session:authSuccess() or not session:authFinalised() then
				--session successfully created
				local sid = session:sessionId()
				local uri = web:link (web.path .. "/" .. sid)
				web.headers["Location"] = uri
				web.status = 303
				return json.encode({message = "Redirecting to new session at " .. uri})
			else
				web.status = 401
				return json.encode({['error'] = "Invalid login credentials"});
			end
		end
	end

	--error case
	web.status = 401
	--web.headers["WWW-Authenticate"] = "Token realm=\"" .. Realm .. "\""
	return json.encode({['error'] = err or "No Error Available"})
end


--- Attempt to retrieve an authentication session
function Auth.session_get(web, params, fields, handle)
	local sid = params.sid

	local ret_status = 400
	local ret_body = {}
	ret_body['session'] = sid

	if sid ~= nil then

		local session = ogsession.Session(sid)
		if session == nil then
			-- sid was invalid
			ret_status = 404
			ret_body['error'] = sid_err
		else
			ret_status = 200
			-- respond with session data
			ret_body['state'] = session:authStatusString()
			ret_body['user'] = session:getUsername()
			-- the ogsession stuff doesn't expose expiry times
			--ret_body['seconds_remaining'] = expiry - os.time()
			if session:getPrompt():len() > 0 then
				ret_body['last_challenge'] = session:getPrompt()
			end
			-- the ogsession stuff doesn't seem to store errors, as distinct from
			-- prompts
			--ret_body['last_error'] = "" --auth_err
			--ret_body['last_info'] = "" --auth_info
		end
	end

	web:content_type ("application/json")
	web.status = ret_status
	return json.encode(ret_body)
end


-- Attempt to apply a response to a pending challenge
function Auth.session_apply_response(web, params, fields, handle)
	local sid = params.sid

	local ret_status = nil
	local ret_body = {}
	ret_body['session'] = sid

	-- Decode PUT data
	local body_data = web.vars.input:read()
	local success, body = common.safeDecode(body_data)
	if (not success) or (body.response == nil) or (body.response ==	json.util.null) then
		ret_status = 400
		ret_body['error'] = "Invalid request body"

	else
		-- Attempt to apply response
		local session = ogsession.Session(sid)
		local success = false
		if session ~= nil then
			session:continueSession()
			if not session:authFinalised() then
				if string.len(body.response) > 0 then
					success = session:setReply(body.response)
				else
					success = session:setReply("")
				end
				session:continueSession()
			else
				success = true
			end
		end

		if not success then
			ret_status = 404
			ret_body['error'] = "Failed to apply response."
		else
			-- All valid session ids garner a state response 
			ret_body['state'] = session:authStatusString()

			if (session:authSuccess() or not session:authFinalised()) then
				-- 200 Success -> continue (even if response was rejected)
				ret_status = 200
				if session:getPrompt():len() > 0 then
					ret_body['challenge'] = session:getPrompt()
				end
			elseif (session:authFinalised() and not session:authSuccess()) then
				-- 403 Forbidden -> no more retries available
				-- XXX: This doesn't differentiate between 'just failed' and
				-- 'was already failed'.
				ret_status = 403
			else
				-- 400 Bad Request -> already authenticated / expired
				ret_status = 400
			end
		end
	end

	web:content_type ("application/json")
	web.status = ret_status
	return json.encode(ret_body)
end


-- Attempt to delete a session
function Auth.session_delete(web, params, fields, handle)
	local sid = params.sid

	local ret_status = 400
	local ret_body = {}
	ret_body['session'] = sid
	ret_body['success'] = false

	if sid ~= nil then
		local session = ogsession.Session(sid)
		if session == nil then
			-- sid was invalid
			ret_status = 404
		else
			session:deleteSession()
			ret_status = 200
			-- respond with session data
			ret_body['state'] = session:authStatusString()
			ret_body['user'] = session:getUsername()
			ret_body['success'] = true
		end
	end

	web:content_type ("application/json")
	web.status = ret_status
	return json.encode(ret_body)
end

return Auth -- return module

-- vim: set tabstop=4 softtabstop=4 shiftwidth=4 noexpandtab : --

