-------------------------------------------------------------------------------
-- Secure Shell configuration and status for Opengear devices.
-- @module SecureShell
-- @author Justin Akers <justin.akers@opengear.com>
-- @copyright 2015 Opengear
--
-- Design / documentation for this API is available at:
-- https://cvs.opengear.com:8443/Product_Development/New_Architecture/Console_Server_REST_API
--
-- XXX: Some of these functions should be protected by authorization however
-- that isn't implemented in this REST API yet.
-------------------------------------------------------------------------------
local SecureShell = {}

--- Includes
local json = require "json"
local common = require "commands/common"
local ogutils = require "ogutils"
local md5 = require "md5"
require "luaconfig"
require "lfs"
require "posix"

function SecureShell.patch_user_authorized_keys(web, params, fields, handle)
	web:content_type("application/json")

	if params.username == nil or string.len(params.username) <= 0 then
		web.status = 400
		return json.encode({['error'] = 'Invalid parameter'})
	end

	local homedir, err = ogutils.get_home_dir(params.username)
	if homedir == nil then
		web.status = 404
		return json.encode({['error'] = 'Username not found: ' .. err})
	end

	-- Solidify user's authorized_keys file. On console server this may be a
	-- dangling symlink so create an empty file if required.
	local user_ak_file_base = homedir .. '/.ssh/authorized_keys'
	local user_ak_file = posix.readlink(user_ak_file_base)
	if user_ak_file == nil then
		local f = io.open(user_ak_file_base, 'w+')
		f:write('# ' .. params.username .. ' authorized keys\n')
		f:flush()
		f:close()
		user_ak_file = user_ak_file_base
		if posix.stat(user_ak_file) == nil then
			web.status = 500
			return json.encode({['error'] = 'Could not create new authorized key file'})
		end
	end

	local body_data = web.vars.input:read()
	local body_ok, body = common.safeDecode(body_data)
	if body_ok == false or body.keys == nil then
		web.status = 400
		return json.encode({['error'] = 'Invalid request body'})
	end

	-- Create temporary file for modifications. Cannot use os.tmpname() here as
	-- CS mounts tmpdir on a different filesystem.
	local akmod_name = user_ak_file .. '.tmp'
	local akmod, err = io.open(akmod_name, 'w+')
	if akmod == nil then
		os.remove(akmod_name) -- os.tmpname may have already been created
		web.status = 500
		return json.encode({['error'] = 'Failed to create temporary file: ' .. err})
	end

	-- Copy existing lines (if any) to new file
	local write_ret = 1
	for origline in io.lines(user_ak_file) do
		keytype, key, comment = string.match (origline, '([^ ]+) +([^ ]+) +([^ ]+)')

		local exists = false
		if comment ~= nil then
			for _, newkey in pairs (body.keys) do
				if newkey.keytype == keytype and newkey.identifier == comment then
					exists = true
				end
			end

		end
		if not exists then
			write_ret, err = akmod:write(origline .. '\n')
			if write_ret == nil then break end
		end
	end

	if write_ret ~= nil then
		-- Append new key(s)
		for _, v in pairs(body.keys) do
			write_ret, err = akmod:write(v.keytype .. ' ' .. v.key .. ' ' .. v.identifier .. '\n')
			if write_ret == nil then break end
		end
	end
	akmod:flush()
	akmod:close()

	if write_ret == nil then
		os.remove(akmod_name) -- os.tmpname may have already been created
		web.status = 500
		return json.encode({['error'] = 'Failed to create new user AK file: ' .. err})
	end

	write_ret, err = os.rename(akmod_name, user_ak_file)
	if write_ret == nil then
		os.remove(akmod_name) -- os.tmpname may have already been created
		web.status = 500
		return json.encode({['error'] = 'Failed to atomically move new file: ' .. err})
	end

	web.status = 200
	return json.encode({message = "OK"})
end

function SecureShell.get_ssh(web, params, fields, handle)
	web:content_type("application/json")

	local mgr = luaconfig.ConfigManager()
	if (mgr == nil) or (not mgr:read()) then
		web.status = 500
		return json.encode({['error'] = 'Failed to open configuration handle'})
	end

	local ssh_port = mgr:getElement("config.services.ssh.port")
	if (ssh_port == nil) or (type(ssh_port) ~= "string") or (ssh_port == "") then
		ssh_port = "22"
	end

	web.status = 200
	return json.encode({ssh = {port = tonumber(ssh_port)}})
end

function SecureShell.get_host_keys(web, params, fields, handle)
	web:content_type("application/json")

	local key_table = {}

	-- Find all public host key files and return contents in a table by key type
	local config_dir = '/etc/config/'
	for fname in lfs.dir(config_dir) do
		local key_type = fname:match('^ssh_host_([a-zA-Z0-9]+)_key.pub$')
		if key_type ~= nil then
			local f, ferr = io.open(config_dir .. '/' .. fname, "rb")
			if f ~= nil then
				key_table[key_type] = ogutils.trim(f:read("*all"))
				f:close()
			end
		end
	end

	-- Nodes should always have at least one host key
	if ogutils.table_key_count(key_table) <= 0 then
		web.status = 500
		return json.encode({['error'] = 'No host public keys found'})
	end

	web.status = 200
	local strdata = json.encode({keys = key_table})
	web.headers["ETag"] = md5.sumhexa (strdata)
	return strdata

end

return SecureShell -- return module

-- vim: set tabstop=4 softtabstop=4 shiftwidth=4 noexpandtab : --

