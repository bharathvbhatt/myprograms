-------------------------------------------------------------------------------
-- Serial Port configuration and status for Opengear devices.
-- @module SerialPorts
-- @author Justin Akers <justin.akers@opengear.com>
-- @copyright 2015 Opengear
--
-- Design / documentation for this API is available at:
-- https://cvs.opengear.com:8443/Product_Development/New_Architecture/Console_Server_REST_API
--
-- Ideally the data reported here should match what the console server CGI shows
-- at all times. This includes special logic for missing or empty fields and
-- entire missing sub-trees.
-------------------------------------------------------------------------------
local SerialPorts = {}

--- Includes
local json = require "json"
local common = require "commands/common"
local bit = require "bit"
local md5 = require "md5"

require "luaconfig"


--- Retrieve a table of capabilities for a serial port.
-- @param mgr A ConfigManager userdata value
-- @param port_num A port number (indexed from 1)
-- @returns caps A table of capabilities (enum value missing = false etc)
local function get_port_capabilities(mgr, port_num)
	local caps = {}

	local cbf = luaconfig.serial_get_capabilities(mgr, port_num)
	caps.serial_parameters =
		not not (bit.band(cbf, luaconfig.SERIAL_PARAMETERS) > 0)
	caps.serial_parameters_proto =
		not not (bit.band(cbf, luaconfig.SERIAL_PARAMETERS_PROTO) > 0)
	caps.serial_parameters_pinout =
		not not (bit.band(cbf, luaconfig.SERIAL_PARAMETERS_PINOUT) > 0)
	caps.console_server_mode =
		not not (bit.band(cbf, luaconfig.SERIAL_CONSOLE_SERVER_MODE) > 0)
	caps.console_server_power_menu =
		not not (bit.band(cbf, luaconfig.SERIAL_CONSOLE_SERVER_POWER_MENU) > 0)
	caps.device_mode =
		not not (bit.band(cbf, luaconfig.SERIAL_DEVICE_MODE) > 0)
	caps.sdt_mode =
		not not (bit.band(cbf, luaconfig.SERIAL_SDT_MODE) > 0)
	caps.terminal_server_mode =
		not not (bit.band(cbf, luaconfig.SERIAL_TERMINAL_SERVER_MODE) > 0)
	caps.serial_bridge_mode =
		not not (bit.band(cbf, luaconfig.SERIAL_SERIAL_BRIDGE_MODE) > 0)
	caps.syslog_support =
		not not (bit.band(cbf, luaconfig.SERIAL_SYSLOG_SUPPORT) > 0)
	caps.nagios_support =
		not not (bit.band(cbf, luaconfig.SERIAL_NAGIOS_SUPPORT) > 0)
	caps.builtin_nmea =
		not not (bit.band(cbf, luaconfig.SERIAL_BUILTIN_NMEA) > 0)
	caps.raw = cbf

	return caps
end

local function get_caps_bool_list(cap_set, default)
	local t = {not not default}
	if cap_set then t[#t + 1] = not default end
	return t
end

--- Retrieve a table representing port configuration
local function get_port_table(mgr, port_num, comprehensive)
	assert(type(port_num) == 'number')

	-- Build port prefix
	local pref = 'config.ports.port' .. port_num .. '.'

	-- IDs are strings
	local p = {id = string.format('port%d', port_num)}

	-- Get port capabilities
	local caps = get_port_capabilities(mgr, port_num)

	-- For development: expose debugging information
	--[[
		p.debug = {}
		p.debug.capabilities = caps
		p.debug.factoryOptions = mgr:getFeatureSetValue('factory_opts')
	]]--

	-- TODO: Do we want to make it a 'slave' port type?

	-- Derive the hardware type
	local hwtype_usb_removable = 'removableUSB'
	local hwtype_usb_builtin = 'builtInUSB'
	--local hwtype_serial_removable = 'removableUART' -- NOT IMPLEMENTED
	local hwtype_serial_builtin = 'builtInUART'

	local typedesc_long = mgr:getSerialPortTypeDesc(port_num)
	local typedesc = ''
	if typedesc_long == '' then
		-- defaults to serial when the hwtype is unknown - the known (expected)
		-- case of this is for cascaded ports.
		p.hardwareType = hwtype_serial_builtin
	else
		typedesc = luaconfig.serial_short_typedesc(typedesc_long)
	end

	if typedesc == '' then
		-- defaults to serial when the hwtype is unknown - the known (expected)
		-- case of this is for cascaded ports.
		p.hardwareType = hwtype_serial_builtin
	elseif typedesc == 'USB' then
		-- NOTE: ConfigManager::isUSBPort only returns true for external USB ports
		-- and doesn't initialise it's second return value unless the device is a
		-- Cisco console or is a symlink to /dev/null. Super helpful.
		local hw_is_external_usb, hw_external_usb_is_connected = mgr:isUSBPort(port_num)
		local port_is_nmea = mgr:isNMEAPort(port_num)
		if hw_is_external_usb then
			p.hardwareType = hwtype_usb_removable
		elseif port_is_nmea then
			-- NOTE: assume 'NMEA ports' are provided by internal USB modems for now
			p.hardwareType = hwtype_usb_builtin
		end
	elseif typedesc == 'RJ45' then
		p.hardwareType = hwtype_serial_builtin
	end

	-- NOTE: CS CGI implies loglevel is specific to console server mode however
	-- it appears to be used by other modes. It is also displayed on the serial
	-- ports list page regardless of mode.
	local loglevel_unknown = 'unknown'
	local loglevel_disabled = 'disabled'
	local loglevel_access = 'access'
	local loglevel_access_io = 'accessInputOutput'
	local loglevel_access_i = 'accessInput'
	local loglevel_access_o = 'accessOutput'
	local loglevel_str = {
		['0'] = loglevel_disabled,
		['1'] = loglevel_access,
		['2'] = loglevel_access_io,
		['3'] = loglevel_access_i,
		['4'] = loglevel_access_o,
	}
	local loglevel_raw = common.get_config_elem(mgr, pref .. 'loglevel', '0')

	p.logging = {
		level = loglevel_str[loglevel_raw] or loglevel_unknown,
		facility = string.lower(
			common.get_config_elem(mgr, pref .. 'syslog.facility', 'default')),
		priority = string.lower(
			common.get_config_elem(mgr, pref .. 'syslog.priority', 'default')),
	}

	-- Empty/missing labels are displayed with default labels as on the
	-- console server
	p.label = common.get_config_elem(mgr, pref .. 'label', '')
	if string.len(p.label) <= 0 then
		p.label = luaconfig.serial_get_default_label(port_num)
	end


	-- Local mode values
	local mode_disabled = 'disabled'
	local mode_unknown = 'unknown'
	local mode_console_server = 'consoleServer'
	local mode_sdt_server = 'sdtServer'
	local mode_local_console = 'localConsole'
	local mode_terminal_server = 'terminalServer'
	local mode_bridge = 'bridge'
	local mode_reserved = 'reserved'
	local mode_powerman = 'powerman'

	local mode_str = {
		['unknown'] = mode_unknown,
		['disabled'] = mode_disabled,

		-- normal 'mode' values (with 'none' attachedDeviceType)
		['portmanager'] = mode_console_server,
		['sdt'] = mode_sdt_server,
		['console'] = mode_local_console,
		['terminal'] = mode_terminal_server,
		['bridge'] = mode_bridge,

		-- reserved for attached device linkage (ups, enviro)
		['reserved'] = mode_reserved,

		-- reserved for attached device linkage (rpc) TODO: perhaps just 'reserved'
		['powerman'] = mode_powerman,
	}
	local mode_raw = common.get_config_elem(mgr, pref .. 'mode', mode_disabled)
	p.mode = mode_str[mode_raw] or mode_unknown

	-- If port id is local console port and is unconfigured then it defaults to
	-- local console mode
	local is_console_port = (tonumber(port_num) == mgr:getConsolePort())
	if is_console_port and
		(common.get_config_elem(mgr, pref .. 'mode', nil) == nil) and
		(common.get_config_elem(mgr, pref .. 'device.type', nil) == nil)
	then
		p.mode = mode_local_console
	end


	-- Attached device type values
	local device_type_none = 'none'
	local device_type_unknown = 'unknown'
	local device_type_rpc = 'remotePowerControl'
	local device_type_ups = 'uninterruptiblePowerSupply'
	local device_type_env = 'environmentMonitor'
	local device_type_nmea = 'nmeaSource'
	local device_type_poweralert = 'powerAlert'
	local device_type_str = {
		['none'] = device_type_none,
		['rpc'] = device_type_rpc,
		['ups'] = device_type_ups,
		['enviro'] = device_type_env,
		['poweralert'] = device_type_poweralert,
	}
	local dt_raw = common.get_config_elem(mgr, pref .. 'device.type', device_type_none)
	p.attachedDeviceType = device_type_str[dt_raw] or device_type_unknown

	-- Simulate attached device type if NMEA streaming is enabled and the device
	-- has support.
	local nmea_enabled = common.get_config_elem(mgr, pref .. 'nmea.enabled', '') == 'on'
	if caps.builtin_nmea and nmea_enabled then
		p.attachedDeviceType = device_type_nmea
	end


	-- Hardware setting "constants"
	local proto_unknown = 'unknown'
	local proto_rs232 = 'RS232'
	local proto_rs422 = 'RS422'
	local proto_rs485 = 'RS485'
	local proto_rs485e = 'RS485e'

	local pinout_unknown = 'unknown'
	local pinout_x0 = 'X0'
	local pinout_x1 = 'X1'
	local pinout_x2 = 'X2'
	local pinout_usb = 'USB'

	local parity_none = 'none'
	local parity_unknown = 'unknown'
	local parity_odd = 'odd'
	local parity_even = 'even'
	local parity_mark = 'mark'
	local parity_space = 'space'

	local flowcontrol_unknown = 'unknown'
	local flowcontrol_none = 'none'
	local flowcontrol_none_unpowered = 'noneUnpowered'
	local flowcontrol_hardware = 'hardware'
	local flowcontrol_software = 'software'
	local flowcontrol_software_unpowered = 'softwareUnpowered'

	-- Hardware settings. These are NOT hardwareType-specific as multiple
	-- types will have a baud rate etc and we don't want to define that field
	-- for each one.
	p.hardwareSettings = {}
	if caps.serial_parameters then
		local uart = {}
		uart.dataBits = common.get_config_elem(mgr, pref .. 'charsize', '8')
		uart.stopBits = common.get_config_elem(mgr, pref .. 'stop', '1')
		uart.baud = common.get_config_elem(mgr, pref .. 'speed', '9600')

		-- Parity values
		local parity_str = {
			['none'] = parity_none,
			['odd'] = parity_odd,
			['even'] = parity_even,
			['mark'] = parity_mark,
			['space'] = parity_space,
		}
		local parity_raw =
			string.lower(common.get_config_elem(mgr, pref .. 'parity', parity_none))
		uart.parity = parity_str[parity_raw] or parity_unknown

		-- Flow control values
		local flowcontrol_str = {
			['None'] = flowcontrol_none,
			['None - Flow control signals unpowered'] =
				flowcontrol_none_unpowered,
			['Hardware'] = flowcontrol_hardware,
			['Software'] = flowcontrol_software,
			['Software - Flow control signals unpowered'] =
				flowcontrol_software_unpowered,
		}
		local fc_raw = common.get_config_elem(mgr, pref .. 'flowcontrol', 'None')
		uart.flowControl = flowcontrol_str[fc_raw] or flowcontrol_unknown

		-- Protocol values. These are only valid if the port supports changing
		-- protocols or is a UART.
		if caps.serial_parameters_proto or p.hardwareType == hwtype_serial_builtin
		then
			local proto_str = {
				['rs232'] = proto_rs232,
				['rs422'] = proto_rs422,
				['rs485'] = proto_rs485,
				['rs485e'] = proto_rs485e,
			}
			local proto_raw =
				string.lower(common.get_config_elem(mgr, pref .. 'protocol', proto_rs232))
			p.hardwareSettings.protocol = proto_str[proto_raw] or proto_unknown
		end

		-- Pinouts. These are only valid if the port supports changing pinouts
		-- or is a UART.
		if caps.serial_parameters_pinout or p.hardwareType == hwtype_serial_builtin
		then
			-- NOTE: Different hardware has different default pinouts. Some
			-- hardware has a fixed pinout and does not know in software. The
			-- old UI defaults to 'X2' and stores that in the config however it
			-- simply hides the value if the pinout is not switchable. We need
			-- more accuracy than that here
			-- TODO: Determine more reliable way to find pinout here.
			p.hardwareSettings.pinout =
				common.get_config_elem(mgr, pref .. 'pinout', pinout_x2)
			if (p.hardwareType == hwtype_usb_removable) or
				(p.hardwareType == hwtype_usb_builtin)
			then
				p.hardwareSettings.pinout = pinout_usb
			end
		end

		-- If in local console mode the hardware settings must be drawn from
		-- separate config fields. Some values are fixed in this mode.
		if p.mode == mode_local_console then
			uart.baud = common.get_config_elem(mgr, 'config.console.speed', '115200')
			local fc_raw = common.get_config_elem(mgr, 'config.console.flow', 'None')
			uart.flowControl = flowcontrol_str[fc_raw] or 'unknown'
			uart.stopBits = '1'
			uart.dataBits = '8'
			uart.parity = parity_none

			if p.hardwareType == hwtype_serial_builtin then
				p.hardwareSettings.protocol = proto_rs232
			end
		end

		p.hardwareSettings.uart = uart
	end

	-- If hardware is removable indicate whether it is currently connected.
	-- This is required as we store port configuration upon first connect
	-- and keep it for usability.
	-- TODO: Support removable UARTs here once implemented.
	if hw_is_external_usb then
		--p.hardwareSettings.isConnected = hw_external_usb_is_connected
	end

	-- Nagios options
	p.nagios = {
		enabled = false,
		portLogging = false,
		serialStatus = false,
		name = ''
	}
	if caps.nagios_support then
		p.nagios.enabled =
			common.get_config_elem(mgr, pref .. 'nagios.enabled', '') == 'on'
		p.nagios.portLogging =
			common.get_config_elem(mgr, pref .. 'nagios.port_log', '') == 'on'
		p.nagios.serialStatus =
			common.get_config_elem(mgr, pref .. 'nagios.serial_status', '') == 'on'
		-- TODO: nagios configurator has a few fallbacks including the hostname
		-- if this field is not set. We need to grab it here for completeness.
		p.nagios.name =
			common.get_config_elem(mgr, pref .. 'nagios.name', '')
	end


	-- mode-specific values
	p.modeSettings = {}

	-- Terminal Server Mode --
	local terminal_type_unknown = 'unknown'
	local terminal_type_vt220 = 'VT220'
	local terminal_type_vt102 = 'VT102'
	local terminal_type_vt100 = 'VT100'
	local terminal_type_linux = 'linux'
	local terminal_type_ansi = 'ANSI'
	if (comprehensive and caps.terminal_server_mode)
		or (p.mode == mode_terminal_server)
	then
		local terminal_type_str = {
			['vt220'] = terminal_type_vt220,
			['vt102'] = terminal_type_vt102,
			['vt100'] = terminal_type_vt100,
			['linux'] = terminal_type_linux,
			['ansi'] = terminal_type_ansi,
		}

		local tt_raw = common.get_config_elem(mgr, pref .. 'terminal', terminal_type_vt220)
		p.modeSettings[mode_terminal_server] = {
			['terminalType'] = terminal_type_str[string.lower(tt_raw)] or terminal_type_unknown
		}
	end

	if (comprehensive and caps.serial_bridge_mode)
		or (p.mode == mode_bridge)
	then
		local v = {}
		v.server = {
			address = common.get_config_elem(mgr, pref .. 'bridge.address', json.util.null),
			port = tonumber (common.get_config_elem(mgr, pref .. 'bridge.port', json.util.null)),
		}
		v.rfc2217 = (common.get_config_elem(mgr, pref .. 'bridge.rfc2217', '') == 'on')
		v.sshTunnel =
			(common.get_config_elem(mgr, pref .. 'bridge.ssh.enabled', '') == 'on')

		p.modeSettings[mode_bridge] = v
	end

	if (comprehensive and caps.console_server_mode)
		or (p.mode == mode_console_server)
	then
		local v = {}

		v.telnet = {
			enabled = common.get_config_elem(mgr, pref .. 'telnet', '') == 'on',
			unauthenticated = common.get_config_elem(mgr, pref .. 'unauthtel', '') == 'on',
		}
		v.ssh = {
			enabled = common.get_config_elem(mgr, pref .. 'ssh', '') == 'on',
		}
		v.tcp = {
			enabled = common.get_config_elem(mgr, pref .. 'tcp', '') == 'on',
		}
		v.rfc2217 = {
			enabled = common.get_config_elem(mgr, pref .. 'rfc2217', '') == 'on',
		}
		v.webShell = {
			enabled = common.get_config_elem(mgr, pref .. 'webshell', '') == 'on',
		}

		-- Aliases are stored as a comma-separated list of IPs in CIDR notation.
		-- Return these as nice JSON lists (even when empty).
		local wan = common.get_config_elem(mgr, pref .. 'interfaces.wan', '')
		local lan = common.get_config_elem(mgr, pref .. 'interfaces.lan', '')
		local oobfo = common.get_config_elem(mgr, pref .. 'interfaces.oobfo', '')
		local wlan = common.get_config_elem(mgr, pref .. 'interfaces.wlan', '')

		v.ipAlias = {
			wan = common.tokenizeString(wan, ',', common.trimString),
			lan = common.tokenizeString(lan, ',', common.trimString),
			oobfo = common.tokenizeString(oobfo, ',', common.trimString),
			wlan = common.tokenizeString(wlan, ',', common.trimString),
		}

		-- Force lua-json to treat these fields as arrays even when empty.
		json.util.InitArray(v.ipAlias.wan)
		json.util.InitArray(v.ipAlias.lan)
		json.util.InitArray(v.ipAlias.oobfo)
		json.util.InitArray(v.ipAlias.wlan)

		v.portShare = {
			enabled =
				common.get_config_elem(mgr, pref .. 'portshare.enabled', '') == 'on',
			encryption =
				common.get_config_elem(mgr, pref .. 'portshare.encrypted', '') == 'on',
			authentication =
				common.get_config_elem(mgr, pref .. 'portshare.authorisation', '') == 'on',
			password =
				common.get_config_elem(mgr, pref .. 'portshare.password', json.util.null),
		}

		local accms = tonumber(common.get_config_elem(mgr, pref .. 'delay', 0))
		if accms == nil then accms = 0 end

		v.general = {
			powerMenuEnabled =
				common.get_config_elem(mgr, pref .. 'powermenu', '') == 'on',
			replaceBackspace =
				common.get_config_elem(mgr, pref .. 'backspace', '') == 'on',
			escapeChar =
				common.get_config_elem(mgr, pref .. 'escapechar', '~'),
			accumulateMS = accms
		}

		p.modeSettings[mode_console_server] = v
	end

	if (comprehensive and is_console_port) or (p.mode == mode_local_console) then
		-- localConsole has no special options
		p.modeSettings[mode_local_console] = {}

	end

	if (comprehensive and caps.sdt_mode) or (p.mode == mode_sdt_server) then
		local v = {}

		-- username and password default to 'port%02d' % id if empty
		local def_name = string.format('port%02d', port_num)
		local def_pass = def_name
		v.username = common.get_config_elem(mgr, pref .. 'sdt.username', def_name)
		v.password = common.get_config_elem(mgr, pref .. 'sdt.password', def_pass)

		p.modeSettings[mode_sdt_server] = v
	end

	-- Capabilities / allowed values for enumerations and booleans.
	-- TODO: Many of these values will probably not be variable per port but
	-- instead variable per-device and thus be pushed to a different resource.
	if comprehensive then
		p.capabilities = {}

		-- Available attachedDeviceType options
		-- TODO: What is 'powerman' device type? When is it available?
		local adtl = {}
		if caps.builtin_nmea then
			adtl = {device_type_none, device_type_nmea}
		elseif not caps.device_mode then
			-- NOTE: device_mode seems to be false for USB consoles and GPS
			adtl = {device_type_none}
		else
			adtl = {device_type_none, device_type_rpc, device_type_ups,
					device_type_env}
		end
		p.capabilities.attachedDeviceType = adtl

		-- Available modes options
		local amodes = {mode_disabled}
		if port_num == mgr:getConsolePort() then
			amodes[#amodes + 1] = mode_local_console
		end
		if caps.console_server_mode then
			amodes[#amodes + 1] = mode_console_server
		end
		if caps.sdt_mode then
			amodes[#amodes + 1] = mode_sdt_server
		end
		if caps.terminal_server_mode then
			amodes[#amodes + 1] = mode_terminal_server
		end
		if caps.serial_bridge_mode then
			amodes[#amodes + 1] = mode_bridge
		end
		p.capabilities.mode = amodes

		-- Available hardwareSettings
		p.capabilities.hardwareSettings = {}
		if caps.serial_parameters then
			local uart = {}

			-- Available databits settings
			uart.dataBits = {'5', '6', '7', '8'}
			uart.stopBits = {'1', '1.5', '2'}
			uart.baud = {
				'50', '75', '110', '134', '150', '200', '300', '600', '1200',
				'1800', '2400', '4800', '9600', '19200', '38400', '57600', '115200',
				'230400'}
			uart.parity = {
				parity_none, parity_odd, parity_even, parity_mark, parity_space}
			uart.flowControl = {
				flowcontrol_none, flowcontrol_none_unpowered, flowcontrol_hardware,
				flowcontrol_software, flowcontrol_software_unpowered}

			p.capabilities.hardwareSettings.uart = uart

			-- Available protocols.
			-- 'caps.serial_parameters_proto' = configurable protocol
			if caps.serial_parameters_proto	then
				p.capabilities.hardwareSettings.protocol =
					{proto_rs232, proto_rs422, proto_rs485, proto_rs485e}
			elseif p.hardwareType == hwtype_serial_builtin then
				p.capabilities.hardwareSettings.protocol = {proto_rs232}
			end

			-- Available pinouts.
			-- 'caps.serial_parameters_pinout' = configurable pinout
			if caps.serial_parameters_pinout or p.hardwareType == hwtype_serial_builtin
			then
				if (p.hardwareType == hwtype_usb_removable) or
					(p.hardwareType == hwtype_usb_builtin)
				then
					p.capabilities.hardwareSettings.pinout = {pinout_usb}
				elseif caps.serial_parameters_pinout then
					p.capabilities.hardwareSettings.pinout = {pinout_x1, pinout_x2}
				else
					p.capabilities.hardwareSettings.pinout = {pinout_x2}
				end
			end
		end

		-- Available logging values
		-- TODO: Old UI seems to hide all but log level if SYSLOG_SUPPORT is
		-- not set?!?
		p.capabilities.logging = {}
		p.capabilities.logging.level = {
			loglevel_disabled, loglevel_access, loglevel_access_io,
			loglevel_access_i, loglevel_access_o}
		if caps.syslog_support then
			p.capabilities.logging.facility = {
				'default', 'local0', 'local1', 'local2', 'local3', 'local4',
				'local5', 'local6', 'local7', 'auth', 'authpriv', 'cron',
				'daemon', 'ftp', 'kern', 'lpr', 'mail', 'news', 'user', 'uucp'}
			p.capabilities.logging.priority = {
				'default', 'warning', 'notice', 'info', 'error', 'emergency',
				'debug', 'critical', 'alert'}
		else
			p.capabilities.logging.facility = {}
			p.capabilities.logging.priority = {}
			json.util.InitArray(p.capabilities.logging.facility)
			json.util.InitArray(p.capabilities.logging.priority)
		end

		-- Mode-specific values
		local msc = {}
		if caps.console_server_mode then
			msc.consoleServer = {}
			msc.consoleServer.ssh = get_caps_bool_list(caps.console_server_mode)
			msc.consoleServer.tcp = get_caps_bool_list(caps.console_server_mode)
			msc.consoleServer.general = {}
			--msc.consoleServer.general.accumulateMS = {5}
			msc.consoleServer.general.replaceBackspace =
				get_caps_bool_list(caps.console_server_mode)
			--msc.consoleServer.general.escapeChar = {'~', '!'}
			msc.consoleServer.portShare = {}
			msc.consoleServer.portShare.enabled =
				get_caps_bool_list(caps.console_server_mode)
			msc.consoleServer.portShare.authentication =
				get_caps_bool_list(caps.console_server_mode)
			msc.consoleServer.portShare.encryption =
				get_caps_bool_list(caps.console_server_mode)
			msc.consoleServer.rfc2217 =
				get_caps_bool_list(caps.console_server_mode)
			msc.consoleServer.webShell =
				get_caps_bool_list(caps.console_server_mode)
			msc.consoleServer.telnet =
				get_caps_bool_list(caps.console_server_mode)
		end

		if caps.terminal_server_mode then
			msc.terminalServer = {}
			msc.terminalServer['terminalType'] = {
				terminal_type_vt220, terminal_type_vt102, terminal_type_vt100,
				terminal_type_linux, terminal_type_ansi}
		end

		if caps.serial_bridge_mode then
			msc.bridge = {}
			msc.bridge.rfc2217 =
				get_caps_bool_list(caps.serial_bridge_mode)
			msc.bridge.sshTunnel =
				get_caps_bool_list(caps.serial_bridge_mode)
			-- TODO: server values?
		end

		p.capabilities.modeSettings = msc

	end

	return p
end



--- Retrieve configuration and state of a serial port
function SerialPorts.get_port(web, params, fields, handle)
	web:content_type ("application/json")

	local comprehensive = (web.GET ~= nil and web.GET.comprehensive) and true or false

	-- Open and read the config
	local mgr = luaconfig.ConfigManager()
	if (mgr == nil) or (not mgr:read()) then
		web.status = 500
		return json.encode({['error'] = 'Failed to open configuration handle'})
	end

	-- Check port id is a string 'portN' and retrieve the port number
	local port_id = (type(params.id) == 'string') and params.id or ''
	local port_number = tonumber(string.match(port_id, 'port([0-9]+)'))
	local port_count = mgr:getNumSerialPorts() + mgr:getNumSlavePorts()
	if (port_number == nil) or (port_number <= 0) or (port_number > port_count) then
		web.status = 404
		return json.encode({['error'] = 'Invalid Port ID:' .. port_id })
	end

	-- Get port information
	local port_data, err = get_port_table(mgr, port_number, comprehensive)
	if port_data == nil then
		web.status = 404
		return json.encode({['error'] = err})
	end

	local strdata = json.encode({serialport = port_data})
	web.headers["ETag"] = md5.sumhexa (strdata)
	if web.headers["ETag"] == web.vars["HTTP_IF_NONE_MATCH"] then
		web.status = 304
		return json.encode ({})
	else
		web.status = 200
		return strdata
	end


end


function SerialPorts.get_port_list(web, params, fields, handle)
	web:content_type ("application/json")

	-- Optional comprehensive request parameter
	local comprehensive = (web.GET ~= nil and web.GET.comprehensive) and true or false

	-- Pagination is optional so start with an improbable page size
	local page_size = 100000
	local page_num = 1

	-- Callers must specify both pagination variables or neither
	local paginated = false
	if (web.GET.per_page ~= nil) and (web.GET.page ~= nil) then
		page_size = tonumber(web.GET.per_page)
		page_num = tonumber(web.GET.page)

		if page_size == nil or page_num == nil or page_size <= 0 or page_num <= 0 then
			web.status = 400
			return json.encode({['error'] = 'Invalid pagination values'})
		end
		paginated = true

	elseif (web.GET.per_page ~= nil) or (web.GET.page ~= nil) then
		web.status = 400
		return json.encode({['error'] = 'Invalid partial pagination request'})
	end

	-- Open and read the config
	local mgr = luaconfig.ConfigManager()
	if (mgr == nil) or (not mgr:read()) then
		web.status = 500
		return json.encode({['error'] = 'Failed to open configuration handle'})
	end

	-- Ports are 'numbered' from 1. The paginated list of serial ports have
	-- string 'id' fields so strictly this isn't an 'indexed' array.
	local start = 1 + ((page_num - 1) * page_size)
	local finish = page_num * page_size

	local port_count = mgr:getNumSerialPorts() + mgr:getNumSlavePorts()
	if start > port_count then start = 0 end
	if finish > port_count then finish = port_count end

	local ports = {}
	if start <= finish and start > 0 then
		for port_num = start, finish, 1 do
			local p, err = get_port_table(mgr, port_num, comprehensive)

			-- Ports within this range must be retrievable as range was checked
			if p == nil then
				web.status = 500
				return json.encode({
					['error'] = 'Failed to retrieve port details: ' .. err})
			end

			ports[#ports + 1] = p
		end
	end

	-- Determine total number of pages at this page size. If there are no ports
	-- then there's still 1 page with 0 entries.
	local total_pages = math.max(1, math.ceil(port_count / page_size))

	-- Encode 'meta' with total_pages field for ember-cli-pagination support
	local ret_body = {serialports = ports, meta = {total_pages = total_pages}}

	-- Force json encoder to treat ports as an array even when empty
	json.util.InitArray(ret_body.serialports)

	local strdata = json.encode(ret_body)
	web.headers["ETag"] = md5.sumhexa (strdata)
	if web.headers["ETag"] == web.vars["HTTP_IF_NONE_MATCH"] then
		web.status = 304
		return json.encode ({})
	else
		web.status = 200
		return strdata
	end
end


return SerialPorts -- return module

-- vim: set tabstop=4 softtabstop=4 shiftwidth=4 noexpandtab : --

