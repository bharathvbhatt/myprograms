local json = require "json"
local common = require "commands/common"
require "luacurl"
require "luaconfig"
local base64 = require "base64"

local os = require "os"
local encode = json.encode
local decode = json.decode

local Enrollment = {}

function write_func (userdata, data)
	if userdata.data == nil then userdata.data = "" end

	userdata.data = userdata.data .. data
	userdata.response = true

	return string.len (data)
end

function header_func (headerdata, data)
	local header = nil
	local value = nil

	header, value = data:match("([^:]+): (.*)")
	if header ~= nil and value ~= nil then
		headerdata[header] = value
	end

	return string.len (data)
end

function Enrollment.delete_registration (web, params, fields)
	web:content_type ("application/json")

	-- Open and read the config
	local mgr = luaconfig.ConfigManager ()
	if mgr == nil then
		web.status = 500
		return encode { message = "Failed to open configuration handle." }
	end
	mgr:read ()

	-- Delete lhvpn settings
	mgr:delElement ("config.lhvpn");

	-- Write the config changes to disk
	if not mgr:write () then
		web.status = 500
		return encode { message = "Failed to write changes to configuration." }
	end

	-- Reload the openvpn config
	mgr:schedule ("lhvpn_tunnel")
	mgr:schedule ("api")
	if not mgr:run () then
		web.status = 500
		return encode { message = "Failed to reload server configuration." }
	end

	web.status = 201
	return encode { message = "OK" }
end


function Enrollment.create_registration (web, params, fields)
	web:content_type ("application/json")
	local post_data = web.vars.input:read ()
	local success, body = common.safeDecode (post_data)
	if success == false then
		web.status = 400
		return encode { message = "Invalid request data." }
	end

	if body.server == nil or body.id == nil or body.package_password == nil then
		web.status = 400
		return encode { message = "Request did not contain all required fields" }
	end

	-- Eventually we'll get the package via a REST request
	-- but until we have a server to talk to just use a static URI
	local uuid = body.id
	local server = body.server
	local api_port = body.server_api_port
	if api_port == nil then
		api_port = 443
	end
	local lh_ext_eps = body.lh_ext_eps
	local password = body.package_password

	-- Create list of endpoints to try get the registration package from, including the primary
	-- server and the lh_ext_eps if they were received
	local endpoints = {}
	table.insert (endpoints, {server = server, api_port = api_port})
	if lh_ext_eps ~= nil and type(lh_ext_eps) == "table" then
		for k, v in pairs (lh_ext_eps) do
			server = v.server
			if server == nil then
				web.status = 400
				return encode { message = "Request did not contain all required fields" }
			end
			api_port = v.server_api_port
			if api_port == nil then
				api_port = 443
			end
			table.insert (endpoints, {server = server, api_port = api_port})
		end
	end

	local userdata = { response = false }
	local headerdata = { }
	local result = nil

	for k, v in pairs (endpoints) do
		local url = "https://" .. v.server .. ":" .. tostring(v.api_port) ..
			"/api/v1/nodes/" .. uuid .. "/registration_package?password=" .. password

		local c = curl.new ()
		c:setopt (curl.OPT_URL, url)
		c:setopt (curl.OPT_WRITEFUNCTION, write_func)
		c:setopt (curl.OPT_WRITEDATA, userdata)
		c:setopt (curl.OPT_HEADERFUNCTION, header_func)
		c:setopt (curl.OPT_HEADERDATA, headerdata)
		c:setopt (curl.OPT_FAILONERROR, true)
		c:setopt (curl.OPT_SSL_VERIFYPEER, false)
		result = c:perform ()
		c:close ()

		if result ~= nil and result then
			break
		end
	end

	if not userdata.response or not result or result == nil then
		web.status = 500
		return encode { message = "Failed to retrieve registration package." }
	end

	local json_ok, reply = common.safeDecode(userdata.data)
	if not json_ok or type(reply) ~= 'table' or reply.cert == nil or reply.ca == nil or reply.key == nil then
		web.status = 500
		return encode { message = "Failed to decode registration package response." }
	end

	-- Open and read the config
	local mgr = luaconfig.ConfigManager ()
	if mgr == nil then
		web.status = 500
		return encode { message = "Failed to open configuration handle." }
	end
	mgr:read ()

	local ntp = mgr:getBoolean('config.ntp.enabled')
	if not ntp and headerdata.Date ~= nil and not reply.ignore_date_header then
		--c.f RFC2616 section 3.3.1
		--Only handle the RFC822/RFC1123 format for now, that's what nginx generates
		--there are two other 'acceptable' formats (RFC850/RFC1036 and asctime()) but
		--nginx doesn't use them.
		local day, month, year, hour, minute, second, tz = headerdata.Date:match("..., (..) (...) (....) (..):(..):(..) (...)")
		if month == "Jan" then
			month = "01"
		elseif month == "Feb" then
			month = "02"
		elseif month == "Mar" then
			month = "03"
		elseif month == "Apr" then
			month = "04"
		elseif month == "May" then
			month = "05"
		elseif month == "Jun" then
			month = "06"
		elseif month == "Jul" then
			month = "07"
		elseif month == "Aug" then
			month = "08"
		elseif month == "Sep" then
			month = "09"
		elseif month == "Oct" then
			month = "10"
		elseif month == "Nov" then
			month = "11"
		elseif month == "Dec" then
			month = "12"
		end

		if day ~= nil and month ~= nil and hour ~= nil
		and year ~= nil and minute ~= nil then
			os.execute("logger -t rest-api \"setting date and time to " .. month .. day .. hour .. minute .. year .."\"")
			--date accepts the time as MMDDhhmm[[CC]YY]
			os.execute('date -u ' .. month .. day .. hour .. minute .. year )
			os.execute('hwclock --systohc --utc')
		end
	end


	-- Increase the tunnel count
	local tuncount = tonumber (mgr:getElement ('config.lhvpn.tunnels.total'))
	if tuncount == nil then tuncount = 0 end
	tuncount = tuncount + 1
	mgr:setElement ('config.lhvpn.tunnels.total', tuncount)

	-- Generate the tunnel config and write it
	local tun = luaconfig.LighthouseVPNTunnel ()
	tun.uuid = uuid

	-- Replace the tunnel's list of servers with those in the registration package
	server = reply.address
	api_port = reply.server_api_port
	vpn_port = reply.server_vpn_port
	if api_port == nil then api_port = 443 end
	if vpn_port == nil then vpn_port = 1194 end
	tun:addServer (server, api_port, vpn_port)

	lh_ext_eps = reply.lh_ext_eps
	if lh_ext_eps ~= nil then
		for k, v in pairs(lh_ext_eps) do
			server = v.server
			api_port = v.server_api_port
			vpn_port = v.server_vpn_port
			if api_port == nil then api_port = 443 end
			if vpn_port == nil then vpn_port = 1194 end
			tun:addServer (server, api_port, vpn_port)
		end
	end

	tun.cert = reply.cert
	tun.ca = reply.ca
	tun.key = reply.key
	prefix = "config.lhvpn.tunnels.tunnel" .. tuncount
	if tun:save (mgr, prefix) ~= 1 then
		web.status = 500
		return encode { message = "Failed to write changes to configuration." }
	end
	if not mgr:write () then
		web.status = 500
		return encode { message = "Failed to write changes to configuration." }
	end

	-- Reload the openvpn config
	mgr:schedule ("lhvpn_tunnel")
	mgr:schedule ("api")
	if not mgr:run () then
		web.status = 500
		return encode { message = "Failed to reload server configuration." }
	end

	web.status = 201
	return encode { message = "OK" }
end

function Enrollment.update_server_address (web, params, fields)
	web:content_type("application/json")

	if params.id == nil then
		web.status = 400
		return encode { message = 'Parameter \'id\' not provided.' }
	end

	local body_data = web.vars.input:read()
	local body_ok, body = common.safeDecode(body_data)
	if body_ok == false or body.address == nil then
		web.status = 400
		return encode({['error'] = 'Invalid request body'})
	end

	-- Open and read the config
	local mgr = luaconfig.ConfigManager ()
	if mgr == nil then
		web.status = 500
		return encode { message = "Failed to open configuration handle." }
	end
	mgr:read ()

	-- Get LighthouseVPNTunnel by ID
	local prefix = "config.lhvpn.tunnels"
	local count = mgr:getSize (prefix .. ".total")
	local tunnelUpdated = false

	for i = 1, count do
		local tun = luaconfig.LighthouseVPNTunnel ()
		local path = prefix .. ".tunnel" .. tostring(i)
		tun:load (mgr, path)

		if tun.uuid == params.id then
			tunnelUpdated = true
			tun.server_vpn_address = body.address
			if tun:save (mgr, path) ~= 1 then
				web.status = 500
				return encode { message = "Failed to save VPN tunnel details." }
			end
		end
	end

	if not tunnelUpdated then
		web.status = 404
		return encode { message = "Not found" }
	end

	if not mgr:write () then
		web.status = 500
		return encode { message = "Failed to write changes to configuration." }
	end

	web.status = 200
	return json.encode({message = "OK"})
end

return Enrollment

-- vim: set tabstop=4 softtabstop=4 shiftwidth=4 noexpandtab : --

