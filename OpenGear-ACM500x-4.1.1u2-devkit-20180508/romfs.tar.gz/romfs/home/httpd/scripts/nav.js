/*
 * Copyright (c) 2016, Opengear Inc.
 */
var navHidden = 0;
function navSaveCookie() {
	document.cookie = "navHidden=" + navHidden + "; max-age=157680000";
}
function navLoadCookie(h) {
	navHidden = h;
	var val = document.cookie.replace(/(?:(?:^|.*;\s*)navHidden\s*\=\s*([^;]*).*$)|^.*$/, "$1");
	if (val !== "")
		navHidden = 0 + val;
}
function navToggle(bnum) {
	flag = 1 << bnum;
	branch = document.getElementById('branch' + bnum);
	icon = document.getElementById('icon' + bnum);
	if (navHidden & flag) {
		branch.style.display = 'block';
		icon.src = '/pixmaps/icon-collapse.png';
		navHidden &= ~flag;
	} else {
		branch.style.display = 'none';
		icon.src = '/pixmaps/icon-expand.png';
		navHidden |= flag;
	}
	navSaveCookie();
}
function navInit(h, bnum) {
	navLoadCookie(h);
	s = document.location.search;
	pairs = s.split('&');
	for (i = 0; i < pairs.length; i++) {
		pair = pairs[i].split('=');
		if (pair[0] == 'h') {
			navHidden = pair[1];
			break;
		}
	}
	for (i = 0; i < bnum; i++) {
		flag = 1 << i;
		if (navHidden & flag) {
			branch = document.getElementById('branch' + i);
			icon = document.getElementById('icon' + i);
			branch.style.display = 'none';
			icon.src = '/pixmaps/icon-expand.png';
		}
	}
}
