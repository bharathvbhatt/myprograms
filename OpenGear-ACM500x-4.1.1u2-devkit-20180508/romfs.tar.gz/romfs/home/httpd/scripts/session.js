/*
 * Copyright (c) 2009, Opengear Inc.
 */
function redirectWhenReady(req1, req2)
{
	if (req1.readyState != 4 || req2.readyState != 4) {
		return;
	}
	if (location.href.match('/public/logout.html') == null) {
		location.href = '/public/logout.html';
	}
}

function invalidateAuth(user)
{
	button = document.getElementById('action-logout');
	if (button.src.match('-disabled.png') != null) {
		return false;
	}
	button.src = button.src.replace('.png', '-disabled.png');

	if (typeof XMLHttpRequest == 'undefined' ||
	    navigator.userAgent.toLowerCase().indexOf('webkit') != -1) {
		alert('Log out not supported by this browser, please\r\nclose your browser to end this session.');
		return false;
	}

	req1 = new XMLHttpRequest();
	req2 = new XMLHttpRequest();

	req1.onreadystatechange = function() { redirectWhenReady(req1, req2); };
	req1.open('GET', '/pixmaps/' + (new Date()).getTime(), true,
		'nobody', '');
	req1.send(null);

	req2.onreadystatechange = function() { redirectWhenReady(req1, req2); };
	req2.open('GET', '/pixmaps/' + (new Date()).getTime(), true,
		user, '\r\n');
	req2.send(null);
}
