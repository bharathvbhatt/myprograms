/**
  *
  * Copyright 2007 Opengear
  *
  **/
function reorderRows() {
    var table = document.getElementById( "NagiosChecks" )
    numRows = table.rows.length
    for( i = 0;i < numRows/2;i++ ) {
        var row = table.rows[i*2]
        row.cells[0].innerHTML = i + 1 
    }
}

function delRow(id) {
    var table = document.getElementById("NagiosChecks");
    var row = document.getElementById( "NagCheck" + id )
    table.deleteRow( row.rowIndex )

    row = document.getElementById( "NagCheck" + id + "d" )
    table.deleteRow( row.rowIndex )

    reorderRows()
}

function linkPorts(prot,id) {
    var newOpt
    var oldOpt = ""
    if( id.selectedIndex >= 0 ) {
        oldOpt = id.options[id.selectedIndex].text
    }
    var oldOptIndex = 0
    var port
    while( id.options.length ) {
        id.remove(0)
    }
    for (var i = 0; i < id.form.services.options.length; i++) {
        if (id.form.services.options[i].value.split(",")[1] == prot) {
            newOpt = document.createElement('option');
            port = id.form.services.options[i].value.split(",")[0]
            newOpt.text = port
            try {
                id.add( newOpt, null )
            } catch( ex ) {
                id.add( newOpt )
            }
            if( port == oldOpt ) {
                id.selectedIndex = oldOptIndex
            }
            oldOptIndex++
        }
    }
    if( id.options.length == 0 ) {
        newOpt = document.createElement('option');
        newOpt.text = ""
        try {
                id.add( newOpt, null )
        } catch( ex ) {
                id.add( newOpt )
        }
    }
}

function clearAliveRadio() {
	var ar = document.getElementsByName( "aliveRadio" );
	for (var i = 0; i < ar.length; i++) {
		ar[i].checked = false;
	}
}

function sendNagios() {
    var table = document.getElementById( "NagiosChecks" )
    var numRows = table.rows.length
    var check
    var optSet
    var desc
    var endVal = document.getElementById( "postNagios" )
    var i
    var j
    var k
    var ar = document.getElementsByName( "aliveRadio" )

    for( k = 0;k < numRows;k+=2 ) {
        i = table.rows[k].getAttribute( "index" )
        check = document.getElementById( "DD" + i + "A" )
        optSet = document.getElementById( "DD" + i + "B" )

        if( ar[k/2].checked ) {
            desc = "on";
        } else {
            desc = "off";
        }
        desc += ","
        desc += escape(check.options[check.selectedIndex].text )
        desc += ","
        desc += optSet.options[optSet.selectedIndex].value

        var argSet = document.getElementById( "opts" + i )

        if( optSet.selectedIndex == 1 ) {
            var args = document.getElementById( "NagArgs" + i )
            desc += ","
            desc += escape( args.value )
        } else {
            for( j = 0;j < argSet.childNodes.length;j++ ) {
                try {
                    if( argSet.childNodes[j].getAttribute( "value" ) != "undefined" ) {
                        desc += ","
                        desc += argSet.childNodes[j].getAttribute( "key")
                        desc += ","
                        if( argSet.childNodes[j].nodeName == "SELECT" ) {
                            desc += argSet.childNodes[j].options[argSet.childNodes[j].selectedIndex].text
                        } else {
                            desc += escape(argSet.childNodes[j].value)
                        }
                }
                } catch (err) {
                }
            }
        }

        endVal.value += desc
        endVal.value += " "
    }

}

function dropDownChanged(num) {
    var check = document.getElementById( "DD" + num + "A" )
    var optSet = document.getElementById( "DD" + num + "B" )
    var opts = document.getElementById( "opts" + num )
    var defStr = document.getElementById( "defStr" + num )
    var ih = ""
    
    if( optSet.selectedIndex == 1 ) {
        ih = "<input id=\"NagArgs" + num + "\" type=\"text\">"
        opts.innerHTML = ih
    } else {
        ih = standOptsArray[check.selectedIndex]
        if( optSet.selectedIndex == 2 ) {
            ih += " Additional Args: <input id=\"NagOptArgs" + num + "\" type=\"text\">"
        }
    opts.innerHTML = ih
    }
    ih = "<i class=field-input>Default Args: " + defOptsArray[check.selectedIndex] + "</i>"
    defStr.innerHTML = ih
}

function addRow() {
    var table = document.getElementById("NagiosChecks");
    var nextId = table.getAttribute( "nextId" )

    var row = document.createElement("tr")
    row.setAttribute( "id", "NagCheck" + nextId )
    row.setAttribute( "index", nextId )

    var cell = document.createElement("td")
    var numRows = table.rows.length / 2
    cell.setAttribute( "class", "field-nagios-tl" )
    cell.setAttribute( "valign", "top" )
    cell.appendChild(document.createTextNode(numRows + 1))
    row.appendChild( cell )

    cell = document.createElement("td")
    var ih = "<select onchange=\"dropDownChanged(" + nextId + ")\" id=\"DD" + nextId + "A\">"
    var i
    for( i = 0;i < labelArray.length;i++ ) {
        ih += "<option>" + labelArray[i] + "</option>"
    }

    ih += "</select>"
    cell.innerHTML = ih
    cell.setAttribute( "class", "field-nagios-t" )
    cell.setAttribute( "valign", "top" )
    row.appendChild( cell )

    cell = document.createElement("td")
    ih = "<select onchange=\"dropDownChanged(" + nextId + ")\" id=\"DD" + nextId + "B\"><option value=\"default\">Use Default Args</option><option value=\"override\">Override Default Args</option><option value=\"add\">Add to default args</option></select></td>"
    cell.innerHTML = ih
    cell.setAttribute( "class", "field-nagios-t" )
    cell.setAttribute( "valign", "top" )
    row.appendChild( cell )

    cell = document.createElement("td")
    cell.innerHTML = standOptsArray[0]
    cell.setAttribute( "class", "field-nagios-t" )
    cell.setAttribute( "valign", "top" )
    cell.setAttribute( "id", "opts" + nextId )
    row.appendChild( cell )

    cell = document.createElement("td")
    cell.innerHTML = "<i>check-host-alive</i><input type=\"radio\" name=\"aliveRadio\"></td>"
    cell.setAttribute( "class", "field-nagios-t" )
    cell.setAttribute( "valign", "top" )
    cell.setAttribute( "id", "opts" + nextId )
    row.appendChild( cell )

    cell = document.createElement("td")
    ih = "<input type=\"button\" onclick=\"delRow(" + nextId + ")\" value=\"Delete\" class=field-nagios>"
    cell.innerHTML = ih
    cell.setAttribute( "class", "field-nagios-tr" )
    cell.setAttribute( "valign", "top" )
    cell.setAttribute( "id", "opts" + nextId )
    row.appendChild( cell )

    table.appendChild(row);

    row = document.createElement("tr")
    row.setAttribute( "id", "NagCheck" + nextId + "d" )

    cell = document.createElement("td")
    cell.setAttribute( "colSpan", 2)
    cell.setAttribute( "class", "field-nagios-bl")
    cell.innerHTML = "&nbsp"
    row.appendChild( cell )
    cell = document.createElement("td")
    ih = "<i class=field-nagios>Default Args: " + defOptsArray[0] + "</i>"
    cell.innerHTML = ih
    cell.setAttribute( "class", "field-nagios-b" )
    cell.setAttribute( "valign", "top" )
    cell.setAttribute( "id", "defStr" + nextId )
    cell.setAttribute( "colSpan", 2)
    row.appendChild( cell )
    cell = document.createElement("td")
    cell.setAttribute( "class", "field-nagios-br")
    cell.innerHTML = "&nbsp"
    row.appendChild( cell )

    table.appendChild(row);
    var nid = parseInt(nextId) + 1
    table.setAttribute( "nextId", nid )

    var redr = document.getElementById( "content" )
    var par = redr.parentNode.parentNode.parentNode.parentNode
    par.setAttribute( "height", "100%" )
    if( par.rows.length == 3 ) {
        par.insertRow(3)
    } else {
        par.deleteRow(3)
    }
}

