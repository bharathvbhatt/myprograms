/*
 * Copyright (c) 2009, Opengear Inc.
 */

function sectionCollapse(section) {
	section.className = 'collapsed';
	id = section.id.substring('section'.length);
	icon = document.getElementById('section-icon' + id);
	if (icon) {
		icon.src = 'pixmaps/icon-expand.png';
	}
}
function sectionExpand(section) {
	section.className = 'expanded';
	id = section.id.substring('section'.length);
	icon = document.getElementById('section-icon' + id);
	if (icon) {
		icon.src = 'pixmaps/icon-collapse.png';
	}
}
function sectionToggle(id) {
	section = document.getElementById('section' + id);
	if (section.className == 'expanded') {
		sectionCollapse(section);
	} else {
		sectionExpand(section);
	}
}
function sectionsCollapse(mask) {
	sections = document.getElementsByTagName("tbody");
	for (i = 0; i < sections.length; i++) {
		section = sections[i];
		if (section.id.indexOf('section') != 0) {
			continue;
		}
		if (section.className == 'collapsed') {
			continue;
		}
		id = section.id.substring('section'.length);
		// Hack to ensure id 0 is collapsed
		if (mask == -1 || (id & mask) == id) {
			sectionCollapse(section);
		}
	}
}
function sectionsCollapseAll() {
	sectionsCollapse(-1);
}
function sectionsExpand(mask) {
	sections = document.getElementsByTagName("tbody");
	for (i = 0; i < sections.length; i++) {
		section = sections[i];
		if (section.id.indexOf('section') != 0) {
			continue;
		}
		if (section.className == 'expanded') {
			continue;
		}
		id = section.id.substring('section'.length);
		if ((id & mask) == id) {
			sectionExpand(section);
		}
	}
}
