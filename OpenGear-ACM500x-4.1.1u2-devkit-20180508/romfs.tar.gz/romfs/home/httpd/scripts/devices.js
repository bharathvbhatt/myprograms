// IE can't disable select options, the opt* functions
// provide a work around

function optDisable(obj, disable) {
	obj.style.color = disable ? "graytext" : "menutext";
}

function optIsDisabled(obj) {
	if (obj.style.color == "graytext") {
		return true;
	}
	return false;
}

function optUpdateSelected(obj) {
	if (!window.selected) {
		window.selected = new Array();
	}
	window.selected[obj.id] = obj.selectedIndex;
}

function optOnChange(obj) {
	if (optIsDisabled(obj.options[obj.selectedIndex])) {
		obj.selectedIndex = window.selected[obj.id];
	} else {
		optUpdateSelected(obj);
	}
}

function checkDisableAdd() {
	var count;
	var table = document.getElementById( "ConnectionSet" );
	var addButton = document.getElementById( "AddButton" );
	count = serialPorts.length;
	count += networkHosts.length;
	var j;
	for( j = 0;j < RPCList.length;j++ ) {
		count += outletList[j].length;
	}
	count += UPSList.length;

	// We need to subtract UNIT types
	var index;
	var tc;
	for( j = 0;j < table.rows.length;j++ ) {
		index = table.rows[j].getAttribute( "index" );

		tc = document.getElementById( "typeChanger" + index );
		if( tc == undefined ) {
			count++;
		}
	}

	if( count > table.rows.length ) {
		addButton.disabled = false;
	} else {
		addButton.disabled = true;
	}

}


function onClickRPC( id ) {
	// Find the serial dropdown
	var dd = document.getElementById( "RPCDD" + id );
	var outletdd = document.getElementById( "OutletDD" + id );
	var initRPC = dd.options.length;

	// grab array of all possible serial ports
	var newRPCList = Array();
	var newOutletList = Array();

	// find each other row with serial set
	var table = document.getElementById( "ConnectionSet" );

	var index;
	var tc;
	var sdd;
	var outdd;
	var i;
	var j;
	var k;
	var row;

	// Gen a new copy of the arrays
	for( i = 0; i < RPCList.length;i++ ) {
		newRPCList[i] = RPCList[i];
	}
	for( i = 0; i < outletList.length;i++ ) {
		newOutletList[i] = new Array();
		for( j = 0; j < outletList[i].length;j++ ) {
			newOutletList[i][j] = outletList[i][j];
		}
	}

	// For each row, if RPC (but not us), remove outlet from arrays
	for( i = 0;i < table.rows.length;i++ ) {
		// for each row...
		index = table.rows[i].getAttribute( "index" );
		if( index == id ) {
			continue;
		}
		tc = document.getElementById( "typeChanger" + index );
		if( tc == undefined ) {
			continue;
		}
		// If RPC...
		if( tc.value != "RPC" ) {
			continue;
		}

		sdd = document.getElementById( "RPCDD" + index );
		outdd = document.getElementById( "OutletDD" + index );
		
		for( j = 0; j < newRPCList.length;j++ ) {
			if( sdd.options[sdd.selectedIndex].getAttribute("value") == newRPCList[j].value ) {
				for( k = 0;k < newOutletList[j].length;k++ ) {
					if( outdd.options[outdd.selectedIndex].getAttribute("value") == newOutletList[j][k].value.split("_")[0] ) {
						newOutletList[j].splice( k, 1 );
						break;
					}
				}
				break;
			}
		}

	}


	// disable entries not in newUPSList
	var disabled;
	for( j = 0; j <  dd.options.length;j++ ) {
		disabled = true;
		if( newOutletList[j].length > 0 ) {
			disabled = false;
		}
		optDisable(dd.options[j], disabled);
	}

	// Make sure first non-disabled is selected
	for( i = dd.selectedIndex;i < dd.options.length;i++ ) {
		if( optIsDisabled(dd.options[i]) == false ) {
			dd.selectedIndex = i;
			optUpdateSelected(dd);
			break;
		}
	}

	var PDU = outletdd.getAttribute( "RPC" );
	var opt;
	var initOutlet = false;
	if( PDU != dd.selectedIndex ) {
		initOutlet = true;
		// Kill options
		while( outletdd.options.length ) {
			outletdd.remove( 0 );
		}
		for( j = 0;j < outletList[dd.selectedIndex].length;j++ ) {
			try {
				opt = document.createElement( "option" );
				//Split out the first value from the array
				var elems = outletList[dd.selectedIndex][j].value.split("_");
				opt.setAttribute("value", elems[0]);
				opt.text = outletList[dd.selectedIndex][j].label;
				outletdd.add(opt,null);
			} catch(ex) {
				outletdd.add(opt);
			}
		}
		outletdd.setAttribute( "RPC", dd.selectedIndex );
	}

	for( i = 0;i < outletdd.length;i++ ) {
		// Now run through for selectable/disabled
		// populate correct options
		var disabled = true;

		for( j = 0; j < newOutletList[dd.selectedIndex].length;j++ ) {
			//Split out the first value from the array
			var elems = newOutletList[dd.selectedIndex][j].value.split("_");
			if( outletdd.options[i].getAttribute("value") == elems[0] ) {
				disabled = false;
				break;
			}
		}

		optDisable(outletdd.options[i], disabled);
	}


	// Make sure first non-disabled is selected
	if( initOutlet ) {
		for( i = 0;i < outletdd.options.length;i++ ) {
			if( optIsDisabled(outletdd.options[i]) == false ) {
				outletdd.selectedIndex = i;
				optUpdateSelected(outletdd);
				break;
			}
		}
	}

}

function onClickUPS( id ) {
	// Find the serial dropdown
	var dd = document.getElementById( "UPSDD" + id );

	// grab array of all possible serial ports
	var newUPSList = UPSList.slice();

	// find each other row with serial set
	var table = document.getElementById( "ConnectionSet" );

	var index;
	var tc;
	var sdd;
	var i;
	var j;
	var row;
	for( i = 0;i < table.rows.length;i++ ) {
		index = table.rows[i].getAttribute( "index" );
		if( index == id ) {
			continue;
		}
		tc = document.getElementById( "typeChanger" + index );
		if( tc == undefined ) {
			continue;
		}
		if( tc.options[tc.selectedIndex].text != "UPS" ) {
			continue;
		}
		sdd = document.getElementById( "UPSDD" + index );
		
		for( j = newUPSList.length;j >= 0;j-- ) {
			if( sdd.options[sdd.selectedIndex].getAttribute("value") == newUPSList[j].value ) {
				newUPSList.splice( j, 1 );
			}
		}

	}

	// disable entries not in newUPSList
	var disabled;
	for( j = dd.options.length - 1;j >= 0;j-- ) {
		disabled = true;
		for( i = 0;i < newUPSList.length;i++ ) {
			if( dd.options[j].getAttribute("value") == newUPSList[i].value ) {
				disabled = false;
				break;
			}
		}
		optDisable(dd.options[j], disabled);
	}
}

function onClickHost( id ) {
	// Find the serial dropdown
	var dd = document.getElementById( "HostDD" + id );

	// grab array of all possible serial ports
	var newNetworkHosts = networkHosts.slice();

	// find each other row with serial set
	var table = document.getElementById( "ConnectionSet" );

	var index;
	var tc;
	var sdd;
	var i;
	var j;
	var row;
	for( i = 0;i < table.rows.length;i++ ) {
		index = table.rows[i].getAttribute( "index" );
		if( index == id ) {
			continue;
		}
		tc = document.getElementById( "typeChanger" + index );
		if( tc.value != "Host" ) {
			continue;
		}
		sdd = document.getElementById( "HostDD" + index );
		
		for( j = newNetworkHosts.length;j >= 0;j-- ) {
			if( sdd.options[sdd.selectedIndex].getAttribute("value") == newNetworkHosts[j].value ) {
				newNetworkHosts.splice( j, 1 );
			}
		}

	}

	// disable entries not in newNetworkHosts
	var disabled;
	for( j = dd.options.length - 1;j >= 0;j-- ) {
		disabled = true;
		for( i = 0;i < newNetworkHosts.length;i++ ) {
			if( dd.options[j].getAttribute("value") == newNetworkHosts[i].value ) {
				disabled = false;
				break;
			}
		}
		optDisable(dd.options[j], disabled);
	}
}

function onClickSerial( id ) {
	// Find the serial dropdown
	var dd = document.getElementById( "SerialDD" + id );

	// grab array of all possible serial ports
	var newSerialPorts = serialPorts.slice();

	// find each other row with serial set
	var table = document.getElementById( "ConnectionSet" );

	var index;
	var tc;
	var sdd;
	var i;
	var j;
	var row;
	for( i = 0;i < table.rows.length;i++ ) {
		index = table.rows[i].getAttribute( "index" );
		if( index == id ) {
			continue;
		}
		tc = document.getElementById( "typeChanger" + index );
		if( tc == undefined || tc.value != "Serial" ) {
			continue;
		}
		sdd = document.getElementById( "SerialDD" + index );
		
		for( j = 0;j < newSerialPorts.length;j++ ) {
			if( sdd.options[sdd.selectedIndex].getAttribute("value") == newSerialPorts[j].value ) {
				newSerialPorts.splice( j, 1 );
				break;
			}
		}

	}

	// disable entries not in newSerialPorts
	var disabled;
	for( j = dd.options.length - 1;j >= 0;j-- ) {
		disabled = true;
		for( i = 0;i < newSerialPorts.length;i++ ) {
			if( dd.options[j].getAttribute("value") == newSerialPorts[i].value ) {
				disabled = false;
				break;
			}
		}
		optDisable(dd.options[j], disabled);
	}
}

function firstValid( id ) {
	var dd = document.getElementById( id );
	var i;
	for( i = 0;i < dd.options.length;i++ ) {
		if( optIsDisabled(dd.options[i]) == false ) {
			dd.selectedIndex = i;
			optUpdateSelected(dd);
			return;
		}
	}
}


function changeConnType( id ) {
	// Grab the row
	var row = document.getElementById( "Conn" + id );
	var dd = document.getElementById( "typeChanger" + id );
	var newVal = dd.value;

	// reset the second cell
	var cell = row.cells[1];

	// default the second cell
	var ih;
	var i;
	if( newVal == "Serial" ) {
		ih = "<select onfocus=\"onClickSerial('"
			+ id +  "')\""
			+ " onchange=\"optOnChange(this)\""
			+ " id=\"SerialDD" + id + "\">"
		for( i = 0;i < serialPorts.length;i++ ) {
			ih += "<option id=\"" + i + "\" " + "value=\"" +
				serialPorts[i].value + "\">";
			ih += serialPorts[i].label;
			ih += "</option>";
		}
		ih += "</select>";
		cell.innerHTML = ih;
		onClickSerial( id );
		firstValid( "SerialDD" + id );
	} else if( newVal == "Host" ) {
		ih = "<select onfocus=\"onClickHost('"
			+ id +  "')\""
			+ " onchange=\"optOnChange(this)\""
			+ " id=\"HostDD" + id + "\">"
		for( i = 0;i < networkHosts.length;i++ ) {
			ih += "<option id=\"" + i + "\" " + "value=\"" +
				networkHosts[i].value + "\">";
			ih += networkHosts[i].label;
			ih += "</option>";
		}
		ih += "</select>";
		cell.innerHTML = ih;
		onClickHost( id );
		firstValid( "HostDD" + id );
	} else if( newVal == "UPS" ) {
		ih = "<select onfocus=\"onClickUPS('"
			+ id +  "')\""
			+ " onchange=\"optOnChange(this)\""
			+ " id=\"UPSDD" + id + "\">"
		for( i = 0;i < UPSList.length;i++ ) {
			ih += "<option id=\"" + i + "\" " + "value=\"" +
				UPSList[i].value + "\">";
			ih += UPSList[i].label;
			ih += "</option>";
		}
		ih += "</select>";
		cell.innerHTML = ih;
		onClickUPS( id );
		firstValid( "UPSDD" + id );
	} else if( newVal == "RPC" ) {
		ih = "<select onfocus=\"onClickRPC('"
			+ id +  "')\""
			+ " onchange=\""
			+ " optOnChange(this);"
			+ " onClickRPC('" + id
			+ "');\" id=\"RPCDD" + id + "\">"
		for( i = 0;i < RPCList.length;i++ ) {
			ih += "<option id=\"" + i + "\" " + "value=\"" +
				RPCList[i].value + "\">";
			ih += RPCList[i].label;
			ih += "</option>";
		}
		ih += "</select>";
		ih += "<select onfocus=\"onClickRPC('"
			+ id +  "')\""
			+ " onchange=\"optOnChange(this)\""
			+ " id=\"OutletDD" + id + "\" PDU=\"-1\">"
		ih += "</select>";

		cell.innerHTML = ih;
		onClickRPC( id );
		firstValid( "RPCDD" + id );
	}
	// Run through the dropdown and set the first non-disabled option
	// as selected
}

function validConnTypes( id ) {
	// Count all of each type
	var table = document.getElementById( "ConnectionSet" );
	var i;
	var j;
	var index;
	var dd;
	var serialCount = 0;
	var hostCount = 0;
	var RPCCount = 0;
	var UPSCount = 0;
	var numOutlets;
	for( i = 0;i < table.rows.length;i++ ) {
		index = table.rows[i].getAttribute( "index" );
		if( index == id ) {
			continue;
		}
		dd = document.getElementById( "typeChanger" + index );
		if( dd == undefined ) {
			continue;
		}
		switch( dd.value ) {
			case "Serial":
				serialCount += 1;
				break;
			case "Host":
				hostCount += 1;
				break;
			case "RPC":
				RPCCount += 1;
				break;
			case "UPS":
				UPSCount += 1;
				break;
		}
	}

	// Disable any without spare options
	dd = document.getElementById( "typeChanger" + id );
	for( i = 0;i < dd.options.length;i++ ) {
		switch( dd.options[i].value ) {
			case "Serial":
				if( serialCount >= serialPorts.length ) {
					optDisable(dd.options[i], true);
				} else {
					optDisable(dd.options[i], false);
				}
				break;
			case "Host":
				if( hostCount >= networkHosts.length ) {
					optDisable(dd.options[i], true);
				} else {
					optDisable(dd.options[i], false);
				}
				break;
			case "RPC":
				numOutlets = 0;
				for( j = 0;j < RPCList.length;j++ ) {
					numOutlets += outletList[j].length;
				}
				if( RPCCount >= numOutlets ) {
					optDisable(dd.options[i], true);
				} else {
					optDisable(dd.options[i], false);
				}
				break;
			case "UPS":
				if( UPSCount >= UPSList.length ) {
					optDisable(dd.options[i], true);
				} else {
					optDisable(dd.options[i], false);
				}
				break;
		}
	}
}


function addConnectionRow() {
    var table = document.getElementById("ConnectionSet");
    var nextId = table.getAttribute( "nextId" );
    table.setAttribute( "nextId", parseInt( nextId ) + 1 );

    var row = document.createElement("tr");
    row.setAttribute( "id", "Conn" + nextId );
    row.setAttribute( "index", nextId );

    var cell = document.createElement("td");
    var ih = "<select id=\"typeChanger" + nextId + "\" "
		+ " onfocus=\"validConnTypes('" + nextId + "')\"" 
		+ " onChange=\"optOnChange(this);"
		+ " changeConnType(" + nextId + ")\">"
		+ "<option id=\"Serial\" value=\"Serial\">Serial</option>"
		+ "<option id=\"Host\" value=\"Host\">Network Host</option>"
		+ "<option id=\"RPC\" value=\"RPC\">RPC</option>"
		+ "<option id=\"UPS\" value=\"UPS\">UPS</option>"
		+ "</select>";
    cell.innerHTML = ih;
    row.appendChild( cell );
    cell = document.createElement("td");
    row.appendChild( cell );
    cell = document.createElement("td");
    cell.innerHTML = "<input type=\"button\" value=\"Delete\" " +
	"onclick=\"delConnection('" + nextId + "')\">";
    row.appendChild( cell );
    
    table.appendChild(row);
    var table = document.getElementById("ConnectionSet");
    var nextId = table.getAttribute( "nextId" );
    nextId = parseInt( nextId ) - 1;
    validConnTypes( nextId );
    firstValid( "typeChanger" + nextId );
    changeConnType( nextId );
    checkDisableAdd();

}

function delConnection( id ) {
    var table = document.getElementById("ConnectionSet");
    var i;
    var index;
    for( i = 0;i < table.rows.length;i++ ) {
    	index = table.rows[i].getAttribute( "index" );
	if( index == id ) {
		table.deleteRow( i );
    		checkDisableAdd();
		return;
	}
    }
}

function submitString() {
	var table = document.getElementById("ConnectionSet");
	var i;
	var index;
	var retStr = "";
	var dd;
	var unit;
	for( i = 0;i < table.rows.length;i++ ) {
		index = table.rows[i].getAttribute( "index" );
		if( i > 0 ) {
			retStr += ",";
		}
		dd = document.getElementById("typeChanger" + index );
		if( dd == undefined ) {
			retStr += table.rows[i].getAttribute( "UNIT" );
		} else {
			retStr += dd.value;
			switch( dd.value ) {
				case "Serial":
					dd = document.getElementById("SerialDD" + index );
					retStr += dd.options[dd.selectedIndex].getAttribute("value");
					break;
				case "Host":
					dd = document.getElementById("HostDD" + index );
					retStr += dd.options[dd.selectedIndex].getAttribute("value");
					break;
				case "UPS":
					dd = document.getElementById("UPSDD" + index );
					retStr += "D" + dd.options[dd.selectedIndex].getAttribute("value");
					break;
				case "RPC":
					dd = document.getElementById("RPCDD" + index );
					retStr += "D" + dd.options[dd.selectedIndex].getAttribute("value");
					retStr += "_";
					dd = document.getElementById("OutletDD" + index );
					retStr += dd.options[dd.selectedIndex].getAttribute("value");
					break;
			}
		}
	}
	return retStr;
}
